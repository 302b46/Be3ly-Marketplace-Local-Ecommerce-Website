<?php
include "../Login-Register/login-register.php";
 ?>
<!DOCTYPE html>
<html lang="en" dir="ltr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Be3ly</title>
    <link href="logoFavion.png" type="image/png" rel="shortcut icon">

<!--Boostrap CDN-->
<link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@4.5.3/dist/css/bootstrap.min.css" integrity="sha384-TX8t27EcRE3e/ihU7zmQxVncDAy5uIKz4rEkgIXeMed4M0jlfIDPvg6uqKI2xXr2" crossorigin="anonymous">
<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/css/bootstrap.min.css">

<!--Font Awesome CDN-->
<script src="https://kit.fontawesome.com/ba83dadc75.js" crossorigin="anonymous">
</script>

<!--Slick Slider-->
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/slick-carousel/1.9.0/slick.min.css" integrity="sha512-yHknP1/AwR+yx26cB1y0cjvQUMvEa2PFzt1c9LlS4pRQ5NOTZFWbhBig+X9G9eYW/8m0/4OXNx8pxJ6z57x0dw==" crossorigin="anonymous" />
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/slick-carousel/1.9.0/slick-theme.min.css" integrity="sha512-17EgCFERpgZKcm0j0fEq1YCJuyAWdz9KUtv1EjVuaOz8pDnh/0nZxmU6BBXwaaxqoi9PQXnRWqlcDB027hgv9A==" crossorigin="anonymous" />

<!--Custom Stylesheet-->
<!--<link rel="stylesheet" href="stylephp.css"> -->
<link rel="stylesheet" href="stylephp.css?v=<?php echo time(); ?>">   <!-- da ely 5ala ye2ra el ta3dilat mn el css file beta3y -->

<!--search bar -->
<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>

<!-- Show Products  -->
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/material-design-iconic-font/2.2.0/css/material-design-iconic-font.min.css">


</head>
  <body>
    <footer class="bg-light text-center text-lg-start">
      <!-- Grid container -->
      <div class="container p-4">
        <!--Grid row-->
        <div class="row">
          <!--Grid column-->
          <div class="col">
            <h5 class="text-uppercase"> <b>We're here to help</b></h5>

            <!-- *edited* help centre div clickable go to write complains to send to our database -->
            <i class="fas fa-info-circle" style="position: relative; left: -10px;"></i>
            <a href="#">egypt@be3ly.com</a>  <br> <br>
            <div> <a href="#"><button style="background-color: #C0C0C0; color: black; border: 20px solid #C0C0C0; ">
             <i class="fas fa-hands-helping"></i> <h6><b>Help centre</b> </h6> <br> <p> Have a question or an issue?<br> We are here to help </p>  </button><a> </div>
           <br> <br> <b>Follow us in:</b>
           <a href="#" class="fa fa-facebook"></a>
            <a href="#" class="fa fa-twitter"></a>
            <a href="#" class="fa fa-instagram"></a>
            <a href="#" class="fa fa-linkedin"></a> <br> <br>
            Download our app:
            <a href="#" class="fa fa-android"></a>
            <a href="#" class="fa fa-apple"></a>
          </div>
          <!--Grid column-->



          <!--Grid column-->
          <div class="col">
            <a href="mobiles.php" class="text-uppercase"> <b>Mobiles</b></a>

            <ul class="list-unstyled mb-0">
              <li>
                <a href="mobiles.php" class="text-dark">Mobiles</a>
              </li>
              <li>
                <a href="mobiles.php" class="text-dark">Tablets</a>
              </li>
              <li>
                <a href="mobiles.php" class="text-dark">chargers</a>
              </li>
              <li>
                <a href="mobiles.php" class="text-dark">headphones</a>
              </li>
              <li>
                <a href="mobiles.php" class="text-dark">USB cables</a>
              </li>
              <li>
                <a href="mobiles.php" class="text-dark">Mobiles accesories</a>
              </li>
            </ul>
    <br>
            <a href="electronics.php" class="text-uppercase"> <b>Electronics</b></a>

    <ul class="list-unstyled mb-0">
      <li>
        <a href="electronics.php" class="text-dark">Laptops</a>
      </li>
      <li>
        <a href="electronics.php" class="text-dark">Tablets</a>
      </li>
      <li>
        <a href="electronics.php" class="text-dark">printers</a>
      </li>
      <li>
        <a href="electronics.php" class="text-dark">TV's</a>
      </li>
      <li>
        <a href="electronics.php" class="text-dark">Camera</a>
      </li>
      <li>
        <a href="electronics.php" class="text-dark">Video Games</a>
      </li>
    </ul>

          </div>
          <!--Grid column-->

          <!--Grid column-->
          <div class="col">
            <a href="fashion.php" class="text-uppercase mb-0"><b>Fashion</b></h5>

            <ul class="list-unstyled">
              <li>
                <a href="fashion.php" class="text-dark">Women's wear</a>
              </li>
              <li>
                <a href="fashion.php" class="text-dark">Men's wear</a>
              </li>
              <li>
                <a href="fashion.php" class="text-dark">Kids wear</a>
              </li>
              <li>
                <a href="fashion.php" class="text-dark">Eye Wear</a>
              </li>
              <li>
                <a href="fashion.php" class="text-dark">Watches</a>
              </li>
              <li>
                <a href="fashion.php" class="text-dark">Bags & Luggage</a>
              </li>
            </ul>

            <a href="supermarket.php" class="text-uppercase mb-0"><b>Supermarket</b></h5>

    <ul class="list-unstyled">
      <li>
        <a href="supermarket.php" class="text-dark">Pasta & Rice</a>
      </li>

      <li>
        <a href="supermarket.php" class="text-dark">Food</a>
      </li>
      <li>
        <a href="supermarket.php" class="text-dark">Cooking Essentials</a>
      </li>

      </li>
    </ul>

          </div>

          <div class="col">
            <a href="toys.php" class="text-uppercase mb-0"><b>Toys</b></h5>

            <ul class="list-unstyled">
              <li>
                <a href="toys.php" class="text-dark">Trampoline</a>
              </li>
              <li>
                <a href="toys.php" class="text-dark">Dolls</a>
              </li>
              <li>
                <a href="toys.php" class="text-dark">Cars</a>
              </li>
              <li>
                <a href="toys.php" class="text-dark">Activities</a>
              </li>


            </ul>
    <br> <br>
    <?php

        if (empty($_SESSION['Username'])){
          echo ' <a class="text-uppercase mb-0"><b>MY ACCOUNT</b></h5>
             <ul class="list-unstyled">
               <li>
                  <a href="http://localhost/Be3ly-Marketplace/Login-Register/login.php" class="text-dark">Sign In</a>
               </li>
               <li>
                  <a href="http://localhost/Be3ly-Marketplace/Login-Register/registeration.php" class="text-dark">Create an Account</a>
               </li>
              </ul> ';
        }
      else if (isset($_SESSION['Username'])) {
          echo '
          <a href="http://localhost/Be3ly-Marketplace/CustomerProfile/profile.php" class="text-uppercase mb-0"><b>MY ACCOUNT</b></h5>
             <ul class="list-unstyled">
               <li>
                 <a href="http://localhost/Be3ly-Marketplace/CustomerProfile/profile.php" class="text-dark">Profile</a>
               </li>
                  </ul>
                   ';
        }
     ?>

          </div>



          <!--Grid column-->
        </div>
        <!--Grid row-->
      </div>


    </div>

      <!-- Grid container -->

      <!-- Copyright -->
      <div class="text-center p-3" style="background-color: rgba(0, 0, 0, 0.2)">
        © 2020 Copyright:
        <a class="text-dark" href="http://localhost/Be3ly-Marketplace/Homepage/HomePagePHP.php">Be3ly.com</a>
      </div>
      <!-- Copyright -->
    </footer>
    <script src="https://code.jquery.com/jquery-3.5.1.slim.min.js" integrity="sha384-DfXdz2htPH0lsSSs5nCTpuj/zy4C+OGpamoFVy38MVBnE+IbbVYUew+OrCXaRkfj" crossorigin="anonymous"></script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@4.5.3/dist/js/bootstrap.bundle.min.js" integrity="sha384-ho+j7jyWK8fNQe+A12Hb8AhRq26LrZ/JpcUGGOn+Y7RsweNrtN/tE3MoK7ZeZDyx" crossorigin="anonymous">
    </script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/slick-carousel/1.9.0/slick.min.js" integrity="sha512-HGOnQO9+SP1V92SrtZfjqxxtLmVzqZpjFFekvzZVWoiASSQgSr4cw9Kqd2+l8Llp4Gm0G8GIFJ4ddwZilcdb8A==" crossorigin="anonymous"></script>
    <script src="D:college/Semester 5/Web Dev/project/farida's work/Be3ly/js/main.js"></script>
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>

    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/js/bootstrap.min.js"></script>
  </body>

</html>
