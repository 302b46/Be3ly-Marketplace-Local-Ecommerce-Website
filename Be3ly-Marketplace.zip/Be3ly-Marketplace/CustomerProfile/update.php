
<?php

$conn = mysqli_connect('localhost', 'root', '', 'be3ly');


if (isset($_POST['save'])) {
  $name=$_POST['name'];
  $username = $_POST['username'];
  $address=$_POST['address'];
  $phone=$_POST['phone'];

  $sql="UPDATE user SET Name='$name',Address='$address',PhoneNumber='$phone' WHERE Username='$username'";
  $query = mysqli_query($conn,$sql);
  //echo '<script>alert("Record updated successfully!")</script>';
}
  if (isset($_POST['savePass'])) {

    $password1 = $_POST['password1'];
    $password2 = $_POST['password2'];
    if ($password1==$_POST['pass'])
    {
      $username=$_POST['username'];
      $pass="UPDATE user SET Password='$password2' WHERE Username='$username'";
      $query2 = mysqli_query($conn,$pass);
      echo '<script>alert("Record updated successfully!")</script>';

    }
    else {
      echo "Failed to change password";
    }
  }

 //  else if ($password_1!=$password_2){
 //    header("refresh:1; url=profile.php");
 //    echo "Passwords do not match";
 //    echo "<br>";
 // }


  //if($query2 || $password_1==$password_2){


      //echo '<script>alert("Record updated successfully!")</script>';

  //}
    // else {
    //   header("refresh:1; url=profile.php");
    //   echo "Update Failed";
    // }


?>
