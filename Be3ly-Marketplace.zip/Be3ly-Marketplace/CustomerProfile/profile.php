<?php
include "update.php";
include "../header.php";

?>
<!DOCTYPE html>
<html lang="en" dir="ltr">
  <head>
    <meta charset="utf-8">
    <title>Customer Profile</title>
    <!-- Customer Profile Bootstrap -->
    <link href="maxcdn.bootstrapcdn.com/bootstrap/4.1.1/css/bootstrap.min.css" rel="stylesheet" id="bootstrap-css">
    <script src="maxcdn.bootstrapcdn.com/bootstrap/4.1.1/js/bootstrap.min.js"></script>
    <script src="cdnjs.cloudflare.com/ajax/libs/jquery/3.2.1/jquery.min.js"></script>
    <script src="js/CustomerPhoto.js"></script>

    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>
    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/css/bootstrap.min.css">
    <link rel="stylesheet" href="https://fonts.googleapis.com/icon?family=Material+Icons">

    <!-- CHANGE PASSWORD MODAL + BOOTSTRAP TABLE -->
    <link href="maxcdn.bootstrapcdn.com/bootstrap/4.1.3/css/bootstrap.min.css" rel="stylesheet" id="bootstrap-css">
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/css/bootstrap.min.css">

  </head>
  <div class="container bootstrap snippet">
      <div class="row"> <!--Beginning of first container-->
    		<div class="col-sm-10"><h1>
          <?php
            $Username=$_SESSION['Username'];
            $sql = "SELECT * FROM user WHERE Username='$Username'";
            $query = $conn->query($sql);
            $total=mysqli_num_rows($query);
            $row=$query->fetch_assoc();
            echo "Welcome ".$row['Name'];
         ?></h1></div>

      	<div class="col-sm-2"><a href="/users" class="pull-right"></a></div>
      </div>
      <div class="row">
    		<div class="col-sm-3"><!--left col-->

        <div class="text-center">

          <!--Displaying profile picture from the database-->
          <?php
            $sql="SELECT ProfilePicture FROM user WHERE Username='$Username'";
            $res = mysqli_query($conn,$sql);

            if (mysqli_num_rows($res)>0) {
              while ($images=mysqli_fetch_assoc($res)){  ?>
                <div class="alb">
              <img src="img/<?=$images['ProfilePicture']?>" style="width:200px;border-radius: 200%;height:200px; border-color: #242484;">
             </div>
             <?php  }  }?>
          <br>
          <?php if(isset($_GET['error'])): ?>
            <p><?php echo $_GET['error']; ?></p>
          <?php endif ?>
              <form class="" action="upload.php" method="post" enctype="multipart/form-data">
                <h5>Upload a new photo?</h5>
                <input type="file" name="image" value="">
                <input type="submit" name="submit" value="Upload">
                <input type="hidden" name="username" value="<?php echo $Username ?>">
              </form>

        </div><br> <!--End of first container-->

          </div><!--/col-3-->

          <!--Navigation Tabs-->
      	<div class="col-sm-9">
              <ul class="nav nav-tabs">
                  <li class="active" ><a data-toggle="tab" href="#profile"  style="color:#242484;">Edit Profile</a></li>
                  <li><a data-toggle="tab" href="#messages" style="color:#242484;">Message History</a></li>
                </ul>

              <!--Beginning of profile tab contents-->
              <div class="tab-content">
              <div class="tab-pane active" id="profile">

                    <form class="form" action="" method="post">
                        <div class="form-group">
                          <div class="col-xs-6">
                            <label for="name"><h4>Name</h4></label>
                            <?php

                             ?>
                             <input type="text" class="form-control" name="name" value="<?php echo $row['Name'] ?>">
                            </div>
                        </div>
                        <div class="form-group">

                            <div class="col-xs-6">
                              <label for="username"><h4>Username</h4></label>


                              <input type="text" class="form-control" name="username" value="<?php echo $Username ?>" readonly>

                            </div>
                        </div>

                        <div class="form-group">
                            <div class="col-xs-6">
                                <label for="phone"><h4>Phone Number</h4></label>
                                <input type="text" class="form-control" name="phone" value="<?php echo $row['PhoneNumber'] ?>">
                            </div>
                        </div>

                        <div class="form-group">
                            <div class="col-xs-6">
                                <label for="email"><h4>Email</h4></label>
                                <input type="text" class="form-control" name="email" value="<?php echo $row['Email'] ?>" readonly>
                            </div>
                        </div>

                        <div class="form-group">
                            <div class="col-xs-6">
                                <label for="email"><h4>Address</h4></label>
                                <input type="text" class="form-control" name="address" value="<?php echo $row['Address'] ?>">
                            </div>
                        </div>

                        <div class="form-group">
                            <div class="col-xs-6">
                                <label for="password"><h4>Password</h4></label>
                                <input type="password" class="form-control" name="password" value="<?php echo $row['Password'] ?>" readonly>
                                   <!-- <u><a href="#modal"  style="position:relative;top: -26.5px; right: -260px; height:36px;color:#242484;">Change Password</a></u> -->
                <button type="button" class="btn btn-primary" data-toggle="modal" data-target="#passModal"style="position:relative;top: -35px; right: -242px; height:36px;background-color:#d12626;border-color:#242484;">
                   Change Password
                </button>

                            </div>
                        </div>
                        <div class="form-group">
                             <div class="col-xs-12">
                                  <br>
                                	<button class="btn btn-lg btn-success pull-right" name="save" type="submit" style="background-color:#d12626;border-color:#242484;"><i class="glyphicon glyphicon-ok-sign"></i> Save</button>
                                  <br>
                                  <br>
                                  <hr>
                              </div>
                        </div>
                	</form>

                <hr>

               </div><!--/tab-pane-->
               <!--End of profile tab contents-->

<!--Beginning of message history tab contents-->
                <div class="tab-pane" id="messages">
                  <table class="table table-striped">
<thead>

<tr>
 <th scope="col">Username</th>
 <th scope="col">Message Text</th>
 <th scope="col">Message Date</th>

</tr>
</thead>
<tbody>
  <?php

  $sql = ("SELECT * FROM messages");
  $query = $conn->query($sql);

  while($row=$query->fetch_assoc()){
    $id=$row['sender'];
    $sql_2="SELECT * FROM user WHERE id ='$id'";
    $query2 = $conn->query($sql_2);
    $userRow=$query2->fetch_assoc();
      echo"<tr><form>";
      echo "<td>";
      echo $userRow['Username'];
      echo "</td>";
      echo "<td>";
      echo $row['messageContent'];
      echo "</td>";
      echo "<td>";
      echo $row['messageDate'];
      echo "</td>";
      echo "<input type=hidden name=id value='".$row['id']."'>";
      echo "</form></tr>";
   }
   ?>
</tbody>
</table>


                </div><!--/tab-pane-->
<!--End of message history tab contents-->
            </div><!--/tab-content-->

          </div><!--/col-9-->
      </div><!--/row-->
  <body>
    <!-- Change password modal -->
    <div class="modal fade" id="passModal" tabindex="-1" role="dialog" aria-labelledby="passModalLabel" aria-hidden="true">
      <div class="modal-dialog" role="document">
        <div class="modal-content">
          <div class="modal-header">
          <h3 class="modal-title" id="exampleModalLabel">Change your password</h3>
            <button type="button" class="close" data-dismiss="modal" aria-label="Close" onclick="close()">
              <span aria-hidden="true">&times;</span>
            </button>
          </div>
          <div class="modal-body">
            <form action="" method="post">
              <div class="form-group">
                <?php
                  $Username=$_SESSION['Username'];
                  $sql = "SELECT * FROM user WHERE Username='$Username'";
                  $query = $conn->query($sql);
                  $total=mysqli_num_rows($query);
                  $row=$query->fetch_assoc();
               ?>

                <label for="recipient-name" class="col-form-label">Current Password:</label>
                <input type="password" class="form-control" id="pass1" name="password1">
              </div>
              <div class="form-group">
                <label for="message-text" class="col-form-label">New Password:</label>
                <input type="password" class="form-control" id="pass2" name="password2">
                <input type="text" name="pass" value="<?php echo $row['Password'] ?>" hidden>
                <input type="text" name="username" value="<?php echo $row['Username'] ?>" hidden>
              </div>

          </div>
          <div class="modal-footer">
            <button type="button" class="btn btn-secondary" data-dismiss="modal" onclick="close()">Close</button>
            <input type="submit" class="btn btn-primary" value="Save changes" name="savePass" style="background-color:#242484">
              </form>
            <script>
            function close() {
                   window.location.assign("http://localhost/Be3ly-Marketplace/CustomerProfile/profile.php")
                             }
            </script>
          </div>
        </div>
      </div>
    </div>

  </body>
</html>
<?php
include "../footer.php";
 ?>
