<?php include "login-register.php" ?>

<html>
<head>

  <link rel="stylesheet" type="text/css" href="../CSS/login-register.css">

</head>
<body>

  <div class="header">
  	<h2>Create A New Account</h2>
  </div>

  <form method="post" action="registration.php">
  	<?php include('errors.php'); ?>

    <div class="input-group">
  	  <label>Full Name</label>
  	  <input type="text" name="name" required>
  	</div>

  	<div class="input-group">
  	  <label>Username</label>
  	  <input type="text" name="username" id="username" value="<?php echo $username;?>" required>
  	</div>
    <div id="msg"></div>
  	<div class="input-group">
  	  <label>Email</label>
  	  <input type="email" name="email" id="email" value="<?php echo $email;?>" required>
  	</div>
    <div id="msg"></div>
  	<div class="input-group">
  	  <label>Password</label>
  	  <input id="register-password" type="password" name="password" id="password" required>
  	</div>
  	<div class="input-group">
  	  <label>Confirm password</label>
  	  <input type="password" name="conf_password" required>
  	</div>
    <br />



  	<div class="input-group">
  	  <button  type="submit" class="btn" name="register">Sign Up</button><br />
  	</div>
    <br />

    </p>
<br /><hr /><br />
  	<p style="text-align: center;">
  		Already a member? <a href="login.php">Sign in</a>
  	</p>
  </form>
</body>
</html>
