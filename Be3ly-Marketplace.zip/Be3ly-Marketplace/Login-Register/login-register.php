<?php

//-------------------------------------------REGISTERATION FORM-------------------------------------------//

//initializing registeration variables

$name = "";
$username = "";
$email = "";
$errors = array();
if(isset($_POST['reg_user'])){

//retreiving user input data from form into and putting them into variables

$name = mysqli_real_escape_string($conn , $_POST['name']);
$username = mysqli_real_escape_string($conn , $_POST['username']);
$email = mysqli_real_escape_string($conn , $_POST['email']);
$address=mysqli_real_escape_string($conn , $_POST['address']);
$phone=mysqli_real_escape_string($conn , $_POST['phone']);
$password_1 = mysqli_real_escape_string($conn , $_POST['password']);
$password_2 = mysqli_real_escape_string($conn , $_POST['conf_password']);
$pp = mysqli_real_escape_string($conn , $_POST['ProfilePicture']);

//validating the registeration form's data

if (empty($name)) { array_push($errors, "Name is required"); }
if (empty($username)) { array_push($errors, "Username is required"); }
if (empty($email)) { array_push($errors, "Email is required"); }
if (empty($password_1)) { array_push($errors, "Password is required"); }

if ($password_1 != $password_2)
{
	array_push($errors, "The two passwords do not match");
  }

//checking username and email in database to make sure they do not already exist

$check_user = "SELECT * FROM user WHERE Username='$username' OR  Email='$email' LIMIT 1 ";
$result = mysqli_query($conn, $check_user);
$user = mysqli_fetch_assoc($result);

//checking if user and/or email exist

if($user)
{
  if($user['Username']===$username)
  {
    array_push($errors, "Username already exists, please choose another one.");
  }

  if($user['Email']===$email)
  {
    array_push($errors, "Email already exists, please use another one.");
  }
}

//registering the user into database if there are no errors
if(count($errors)==0)
{
  //registeration query

  $register = "INSERT INTO user (Name, Username, Password, Email, Address, PhoneNumber, ProfilePicture, UserType) VALUES ('$name','$username', '$password', '$email','$address', '$phone', '$pp',4)";
  mysqli_query($conn, $register);
  $_SESSION['Username'] = $username;
  $_SESSION['success'] = "Logging In Successful!";
  header('location:login.php');
}

}

//-------------------------------------------LOGIN FORM-------------------------------------------//

if(isset($_POST['login_user'])) {

  $username = mysqli_real_escape_string($conn, $_POST['username']);
  $password = mysqli_real_escape_string($conn, $_POST['password']);

  if(empty($username)){ array_push($errors, "Username is required");}

  if(empty($password)){ array_push($errors, "Password is required");}

  if(count($errors) == 0) {

  	$login = "SELECT * FROM user WHERE Username='$username' AND Password='$password'";
		$data=mysqli_query($conn,$login);
	  $total=mysqli_num_rows($data);

  	if($total == 1) {

			$user = mysqli_fetch_assoc($data);

  	  $_SESSION['Username'] = $username;
			$_SESSION['Password'] = $password;
      $_SESSION['success'] = "Logging In Successful!";
			//directing user to a homepage based on their user type (admin, auditor, hr, or customer)//

			//Admin Homepage
			if($user['UserType']=='1')
				{
					$_SESSION['Username'] = $username;
					header('location: ../Admin/adminHomepage.php');
					exit;
				}

			//Auditor Homepage
			else if($user['UserType']=='2')
			{
				$_SESSION['Username'] = $username;
				header('location: ../Auditor/auditorHomepage.php');
			}

			//HR Homepage
			else if($user['UserType']=='3')
			{
				$_SESSION['Username'] = $username;
				header('location: hrHomepage.php');
			}

			//Customer Homepage
			else if($user['UserType']=='4')
  	  {
				$_SESSION['Username'] = $username;
				header('location:../Homepage/HomepagePHP.php');
  		}

		else {
  		array_push($errors, "Incorrect Username and/or password.");

  	}

}
}
}

?>
