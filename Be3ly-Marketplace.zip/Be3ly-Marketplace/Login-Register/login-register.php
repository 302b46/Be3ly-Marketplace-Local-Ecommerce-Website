<?php
 include "../database-connection.php";

//-------------------------------------------REGISTRATION FORM-------------------------------------------//

//initializing registration variables

$name = "";
$username = "";
$email = "";
$errors = array();

if(isset($_POST['register'])){

//retreiving user input data from form into and putting them into variables

$name = mysqli_real_escape_string($conn , $_POST['name']);
$username = mysqli_real_escape_string($conn , $_POST['username']);
$email = mysqli_real_escape_string($conn , $_POST['email']);
$password_1 = mysqli_real_escape_string($conn , $_POST['password']);
$password_2 = mysqli_real_escape_string($conn , $_POST['conf_password']);


//---------------------DATA VALIDATION---------------------//

//Checking if input fields are empty

if (empty($name)) { array_push($errors, "Name is required"); }
if (empty($username)) { array_push($errors, "Username is required"); }
if (empty($password_1)) { array_push($errors, "Password is required"); }
if (empty($password_2)) { array_push($errors, "Password confirmation is required"); }

//Checking email format

if(!filter_var($email, FILTER_VALIDATE_EMAIL))
{
  array_push($errors, "Invalid Email Format.");

}

//Checking if passwords match
else if ($password_1 != $password_2)
{
	array_push($errors, "The two passwords do not match");
}
else if(strlen($password_1)<6)
  {
    array_push($errors, "Password must be atleast 6 characters.");

  }



//checking username and email in database to make sure they do not already exist

$check_user = "SELECT * FROM user WHERE Username='$username' OR  Email='$email' LIMIT 1 ";
$result = mysqli_query($conn, $check_user);
$user = mysqli_fetch_assoc($result);

//checking if user and/or email exist

if($user)
{
  if($user['Username']===$username)
  {
    array_push($errors, "Username already exists, please choose another one.");
  }

  if($user['Email']===$email)
  {
    array_push($errors, "Email already exists, please use another one.");
  }
}

//registering the user into database if there are no errors
if(count($errors)==0)
{
  //registration query

  $register = "INSERT INTO user (Name, Username, Password,Email,UserType)
              VALUES ('$name','$username', '$password', '$email',4)";
  mysqli_query($conn, $register);
  $_SESSION['Username'] = $username;
  $_SESSION['success'] = "Logging In Successful!";
  header('location:../Homepage/HomePagePHP.php');
}}



//-------------------------------------------LOGIN FORM-------------------------------------------//

if(isset($_POST['login'])) {

  $username = mysqli_real_escape_string($conn, $_POST['username']);
  $password = mysqli_real_escape_string($conn, $_POST['password']);

  if(empty($username)){ array_push($errors, "Username is required");}

  if(empty($password)){ array_push($errors, "Password is required");}

  if(count($errors) == 0) {

  	$login = "SELECT * FROM user WHERE Username='$username' AND Password='$password'";
  	$results = mysqli_query($conn, $login);


  	if(!mysqli_num_rows($results) == 1)
    {
      array_push($errors, "Incorrect Username and/or password.");

    }
    else
    {

      			$user = mysqli_fetch_assoc($results);


      			//directing user to a homepage based on their user type (admin, auditor, hr, or customer)

      			//Admin Homepage
      			if($user['UserType']=='1')
      				{
                $_SESSION['id'] =$user['id'];
      					$_SESSION['Username'] = $username;
                $_SESSION['success'] = "Logging In Successful!";
      					header('location: ../Admin/adminHomepage.php');
      				}

      			//Auditor Homepage
      			else if($user['UserType']=='2')
      			{
              $_SESSION['id'] =$user['id'];
      				$_SESSION['Username'] = $username;
              $_SESSION['success'] = "Logging In Successful!";

      				header('location: ../Auditor/auditorHomepage.php');
      			}

      			//HR Homepage
      			else if($user['UserType']=='3')
      			{
              $_SESSION['id'] =$user['id'];
      				$_SESSION['Username'] = $username;
      				header('location: ../HR/hrHomepage.php');
      			}

      			//Customer Homepage
      			else if($user['UserType']=='4')
        	  {
              $_SESSION['id'] =$user['id'];
      				$_SESSION['Username'] = $username;
              $_SESSION['success'] = "Logging In Successful!";

      				header('location: ../Homepage/HomePagePHP.php');
        		}
          }
    }


}



?>
