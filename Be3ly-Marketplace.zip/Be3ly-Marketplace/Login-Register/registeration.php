<?php include "../database-connection.php";
include "login-register.php";
?>

<html>
<head>

  <link rel="stylesheet" type="text/css" href="pagelayout.css">
</head>
<body>
  <!-- <img src="logo.png" style="padding-left: 20px;
  padding-top: 20px;
  width: 120px;
  height: 50px;" /> -->
  <div class="header">
  	<h2>Create A New Account</h2>
  </div>

  <form method="post" action="">
  	<?php include('errors.php'); ?>

    <div class="input-group">
  	  <label>Full Name</label>
  	  <input type="text" name="name" value="<?php echo $name; ?>">
  	</div>

  	<div class="input-group">
  	  <label>Username</label>
  	  <input type="text" name="username" value="<?php echo $username; ?>">
  	</div>
  	<div class="input-group">
  	  <label>Email</label>
  	  <input type="email" name="email" value="<?php echo $email; ?>">
  	</div>

    <div class="input-group">
      <label>Phone Number</label>
      <input type="text" name="phone">
    </div>

    <div class="input-group">
      <label>Address</label>
      <input type="text" name="address">
    </div>

  	<div class="input-group">
  	  <label>Password</label>
  	  <input type="password" name="password">
  	</div>
  	<div class="input-group">
  	  <label>Confirm password</label>
  	  <input type="password" name="conf_password">
  	</div>
    <br />
  	  <label>Profile Picture</label>
  	  <input type="file" name="ProfilePicture">


  	<div class="input-group">
  	  <button type="submit" class="btn" name="reg_user">Sign Up</button><br />
  	</div>

    <?php

    if (isset($_POST['submit'])) {

      header('location:login.php');
    }

     ?>

<br /><hr /><br />
  	<p style="text-align: center;">
  		Already a member? <a href="login.php">Sign in</a>
  	</p>
  </form>
</body>
</html>
