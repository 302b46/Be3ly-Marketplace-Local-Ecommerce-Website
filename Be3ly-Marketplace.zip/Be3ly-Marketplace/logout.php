<?php include "../database-connection.php"?>
<?php
session_start();
session_destroy();

//MARKETPLACE HOMEPAGE
header("location:Login-Register/login.php");

 ?>
