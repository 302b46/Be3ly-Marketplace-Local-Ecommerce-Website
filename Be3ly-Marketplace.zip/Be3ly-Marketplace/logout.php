<?php
session_start();
session_destroy();

//MARKETPLACE HOMEPAGE
header("location:Homepage/HomepagePHP.php");

 ?>
