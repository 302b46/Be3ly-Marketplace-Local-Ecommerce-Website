<?php include "../database-connection.php";
include "../Login-Register/login-register.php";
 ?>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Be3ly</title>
    <link href="logoFavion.png" type="image/png" rel="shortcut icon">

<!--Boostrap CDN-->
<link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@4.5.3/dist/css/bootstrap.min.css" integrity="sha384-TX8t27EcRE3e/ihU7zmQxVncDAy5uIKz4rEkgIXeMed4M0jlfIDPvg6uqKI2xXr2" crossorigin="anonymous">
<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/css/bootstrap.min.css">

<!--Font Awesome CDN-->
<script src="https://kit.fontawesome.com/ba83dadc75.js" crossorigin="anonymous">
</script>

<!--Slick Slider-->
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/slick-carousel/1.9.0/slick.min.css" integrity="sha512-yHknP1/AwR+yx26cB1y0cjvQUMvEa2PFzt1c9LlS4pRQ5NOTZFWbhBig+X9G9eYW/8m0/4OXNx8pxJ6z57x0dw==" crossorigin="anonymous" />
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/slick-carousel/1.9.0/slick-theme.min.css" integrity="sha512-17EgCFERpgZKcm0j0fEq1YCJuyAWdz9KUtv1EjVuaOz8pDnh/0nZxmU6BBXwaaxqoi9PQXnRWqlcDB027hgv9A==" crossorigin="anonymous" />

<!--Custom Stylesheet-->
<!--<link rel="stylesheet" href="stylephp.css"> -->
<link rel="stylesheet" href="stylephp.css?v=<?php echo time(); ?>">   <!-- da ely 5ala ye2ra el ta3dilat mn el css file beta3y -->

<!--search bar -->
<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>

<!-- Show Products  -->
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/material-design-iconic-font/2.2.0/css/material-design-iconic-font.min.css">

<style>
.headerbtn {
  background-color: #293a6a;
  border: none;
  color: white;
  padding: 10px 12px;
  font-size: 16px;
  cursor: pointer;
}

.headerbtn:hover {
  background-color: #526789;
}
.headerforms{
  display: inline-block;
}

</style>
</head>
<body>

  <header>
  <div class="container">

      <div class="row">
          <div class="col-12"> <!--12 is the column width-->
              <div class="btn-group">

              </div>
          </div>

          <div class="col-13 text-left" onclick="location.href='http://localhost/Be3ly-Marketplace/Homepage/HomePagePHP.php';" style="cursor: pointer;"  >
              <h1 class="my-site-title"  >
                  <img src="logo.png" alt="Logo" width="170px" height="70px"  >
              </h1>
              </div>
              <?php

                  if (empty($_SESSION['Username'])){
                    echo '<div class="col-12 text-right">
                        <p class="header-links">
                            <a href="http://localhost/Be3ly-Marketplace/Login-Register/login.php" class="px-2">Sign In</a>
                            <a href="http://localhost/Be3ly-Marketplace/Login-Register/registeration.php" class="px-1">Create an Account</a>
                        </p>
                    </div>';
                  }
                else if (isset($_SESSION['Username'])) {
                    echo '<div class="col-12 text-right">
                        <p class="header-links">
                            <form class="headerforms" action="http://localhost/Be3ly-Marketplace/CustomerProfile/profile.php">
                            <button class="headerbtn"><i class="fa fa-user fa-lg"></i></button>
                            </form>
                            <form class="headerforms" action="http://localhost/Be3ly-Marketplace/Homepage/HomePagePHP.php" method="post">
                            <button class="headerbtn"><i class="fa fa-home fa-lg"></i></button>
                            </form>
                            <form class="headerforms" action="http://localhost/Be3ly-Marketplace/cart/cart.php">
                            <button class="headerbtn"><i class="fa fa-shopping-cart fa-lg"></i></button>
                            </form>
                            <form class="headerforms" action="signout.php" method="post">
                            <button class="headerbtn"><i class="fa fa-sign-out fa-lg"></i>Sign Out</button>
                            </form>

                        </p>
                        </div>';
                  }
               ?>

      </div>
  </div>

  <div class="container-fluid p-0">
      <nav class="navbar navbar-expand-lg navbar-light bg-light">
        <!-- edit 1  -->
        <div class="dropdown">
          <button class="btn btn-secondary dropdown-toggle" class="navbar-brand" href="#" type="button" id="dropdownMenuButton" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
            Categories
          </button>
          <div class="dropdown-menu" aria-labelledby="dropdownMenuButton">
            <a href="electronics.php" class="dropdown-item" >Electronics</a>
            <a href="mobiles.php" class="dropdown-item" >Mobiles</a>
            <a href="fashion.php" class="dropdown-item" >Fashion</a>
            <a href="supermarket.php" class="dropdown-item" >Supermarket</a>
            <a href="toys.php" class="dropdown-item" >Toys</a>
          </div>

        </div>
          <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarNav" aria-controls="navbarNav" aria-expanded="false" aria-label="Toggle navigation">
            <span class="navbar-toggler-icon"></span>
          </button>
          <div class="collapse navbar-collapse" id="navbarNav">
            <ul class="navbar-nav">
              <li class="nav-item active">
                <a class="nav-link" href="electronics.php">Electronics<span class="sr-only">(current)</span></a>
              </li>
              <li class="nav-item">
                <a class="nav-link" href="mobiles.php">Mobiles</a>
              </li>
              <li class="nav-item">
                <a class="nav-link" href="fashion.php">Fashion</a>
              </li>
              <li class="nav-item">
                  <a class="nav-link" href="supermarket.php">Supermarket</a>
                </li>
                <li class="nav-item">
                  <a class="nav-link" href="toys.php">Toys</a>
                </li>

            </ul>
          </div>

          <div class="fixed">
          <form method="post">
          Search: <input type="text" name="Search" placeholder="Search for a product..">
          <input type="submit" class="btnFixed" id="myButton" name="submit" value="Search">
          </form>
          <?php

          if(isset($_POST['submit'])){

          $search_value=$_POST["Search"];


          $sqlSearch="SELECT * FROM product WHERE name LIKE '%$search_value%'";

          $resultSearch = $conn->query($sqlSearch);
          $cat=array(); $t=0;
          $idd=array();
          if ($resultSearch->num_rows > 0) {
              while($rowsearch = $resultSearch->fetch_assoc()) {
                $cat[$t]=$rowsearch["category"];
                $idd[$t]=$rowsearch["id"];
               echo "<p><a style='color:black;' href='http://localhost/Be3ly-Marketplace/Homepage/SearchPage.php?id=$idd[$t]' >";
               echo $rowsearch["name"];
               echo "</a></p>";
               } }
               else {
                 echo "not found in database, try again.";
               }



               $conn->close();
          }

          ?>


          </div>


        </nav>
  </div>


  </header>
  <script src="https://code.jquery.com/jquery-3.5.1.slim.min.js" integrity="sha384-DfXdz2htPH0lsSSs5nCTpuj/zy4C+OGpamoFVy38MVBnE+IbbVYUew+OrCXaRkfj" crossorigin="anonymous"></script>
  <script src="https://cdn.jsdelivr.net/npm/bootstrap@4.5.3/dist/js/bootstrap.bundle.min.js" integrity="sha384-ho+j7jyWK8fNQe+A12Hb8AhRq26LrZ/JpcUGGOn+Y7RsweNrtN/tE3MoK7ZeZDyx" crossorigin="anonymous">
  </script>
  <script src="https://cdnjs.cloudflare.com/ajax/libs/slick-carousel/1.9.0/slick.min.js" integrity="sha512-HGOnQO9+SP1V92SrtZfjqxxtLmVzqZpjFFekvzZVWoiASSQgSr4cw9Kqd2+l8Llp4Gm0G8GIFJ4ddwZilcdb8A==" crossorigin="anonymous"></script>
  <script src="D:college/Semester 5/Web Dev/project/farida's work/Be3ly/js/main.js"></script>
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>

  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/js/bootstrap.min.js"></script>
</body>
</html>
