<?php include "adminDashboard.php"?>
<html>
 <head>
  <title>Orders</title>
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/2.1.3/jquery.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.6/js/bootstrap.min.js"></script>
  <link href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.6/css/bootstrap.min.css" rel="stylesheet" />


  <script>
  $(document).ready(function(){

   load_data();

   function load_data(query)
   {
    $.ajax({
     url:"liveSearch.php",
     method:"POST",
     data:{query:query},
     success:function(data)
     {
      $('#result').html(data);
     }
    });
   }
   $('#searchValue').keyup(function(){
    var search = $(this).val();
    if(search != '')
    {
     load_data(search);
    }
    else
    {
     load_data();
    }
   });
  });
  </script>
 </head>
 <body>
  <div class="container">
   <div class="navbar-right">
    <div class="input-group" style="width:200px;">
     <span class="input-group-addon"><i class="fa fa-search"></i></span>
     <input type="text" name="searchValue" id="searchValue" placeholder="Search for Order..." class="form-control" />
    </div>
   </div>
   <br /><br /><br />
   <div id="result"></div>
  </div>
 </body>
</html>
