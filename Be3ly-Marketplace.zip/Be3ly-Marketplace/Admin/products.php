<?php include "adminDashboard.php"?>

<html>
<title>Products</title>

<head>
  <link rel="stylesheet" type="text/css" href="../CSS/tables.css">

  <!-- BOOTSTRAP TABLE -->
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/css/bootstrap.min.css">

  <!-- EDIT/DELETE ICONS -->
  <link rel="stylesheet" href="https://fonts.googleapis.com/icon?family=Material+Icons">

  <!-- AJAX FUNCTIONS FILE -->
  <script src="../Functions/products.js"></script>


</head>

<body>
<div class="container">


  <a href="JavaScript:void(0);" id="delete_selected" data-toggle="modal"style="margin-left:10px;"title="Delete All Selected Products"class="pull-right hidden-xs showopacity glyphicon glyphicon-trash btn btn-danger"></a>

  <a href="#addProductModal" data-toggle="modal" title="Add A New Product"  class="pull-right hidden-xs90 showopacity glyphicon glyphicon-plus btn btn-success" /></a>


  <h2>Manage Products</h2>
  <table class="table table-hover">
    <thead>
      <tr>
        <th>
            <span class="custom-checkbox">
              <input type="checkbox" id="selectAll">
              <label for="selectAll"></label>
            </span>
        </th>
        <th>ID</th>
        <th>Name</th>
        <th>Category</th>
        <th>Description</th>
        <th>Price</th>
        <th>Quantity</th>
        <th>Image</th>
        <th>Action</th>
      </tr>
    </thead>
    <tbody>
    <?php

    $sql ="SELECT * FROM product";
    $result=mysqli_query($conn,$sql);

    while($row=mysqli_fetch_assoc($result)){

      ?>
      <tr id="<?php echo $row["id"]; ?>">
        <td>
          <span class="custom-checkbox">
            <input type="checkbox" class="product_checkbox" data-user-id="<?php echo $row["id"]; ?>">
            <label for="checkbox2"></label>
          </span>
        </td>
        <!-- DISPLAYING PRODUCTS -->
        <td><?php echo $row["id"]?></td>
        <td><?php echo $row["name"]?></td>
        <td><?php echo $row["category"]?></td>
        <td><?php echo $row["description"]?></td>
        <td><?php echo $row["price"]?></td>
        <td><?php echo $row["quantity"]?></td>
        <td><?php echo $row["image"]?></td>

      <td>
        <a href="#editProductModal" class="edit" data-toggle="modal">
          <i class="material-icons update" data-toggle="tooltip"
          data-id="<?php echo $row["id"]; ?>"
          data-name="<?php echo $row["name"]; ?>"
          data-category="<?php echo $row["category"]; ?>"
          data-description="<?php echo $row["description"]; ?>"
          data-price="<?php echo $row["price"]; ?>"
          data-quantity="<?php echo $row["quantity"]?>"
          data-image="<?php echo $row["image"]?>"
          title="Edit">&#xE254;</i>
        </a>
        <a href="#deleteProductModal" class="delete" data-id="<?php echo $row["id"]; ?>"data-toggle="modal">
          <i class="material-icons" data-toggle="tooltip" title="Delete">&#xE872;</i>
        </a>

        </td>

      </tr>
      <?php
      }
      ?>
    </tbody>
  </table>
</div>



<!--- MODALS --->

<!-- Add Product -->

<div id="addProductModal" class="modal fade">
  <div class="modal-dialog">
    <div class="modal-content">
      <form id="product_form">
        <div class="modal-header">
          <h4 class="modal-title">Add A New Product</h4>
          <button type="button" class="close" data-dismiss="modal" aria-hidden="true">&times;</button>
        </div>
         <div class="modal-body">
          <div class="form-group">
            <label>Product Name</label>
            <input type="text" class="form-control" id="name" name="name" required>
          </div>
          <div class="form-group">
            <label>Category</label>
            <select name="category" class="form-control" id="category" name="category" required>
                <option disabled selected value> -- Select a Category -- </option>
                <option value="electronics">Electronics</option>
                <option value="fashion">Fashion</option>
                <option value="supermarket">Supermarket</option>
                <option value="toys">Toys</option>
            </select>
          </div>
          <div class="form-group">
            <label>Description</label><br />
            <textarea name="descprition" id="description" name="description" rows="4" cols="30" required></textarea>
          </div>
          <div class="form-group">
            <label>Price</label>
            <input type="text" class="form-control" id="price" name="price" required>
          </div>
          <div class="form-group">
            <label>Quantity</label>
            <input type="number" class="form-control" id="quantity" name="quantity" required>
          </div>

          <div class="form-group">
            <label>Image &nbsp; </label>
              <input type="file" id="image" name="image" required/>
          </div>
        </div>

        <div class="modal-footer">
            <input type="hidden" value="1" name="type">
          <input type="button" class="btn btn-default" data-dismiss="modal" value="Cancel">
          <button type="button" class="btn btn-success" id="btn-add">Add</button>
        </div>
      </form>
    </div>
  </div>
</div>

<!-- Edit Modal -->

<div id="editProductModal" class="modal fade">
  <div class="modal-dialog">
    <div class="modal-content">
      <form id="update_form">
        <div class="modal-header">
          <h4 class="modal-title">Edit Product</h4>
          <button type="button" class="close" data-dismiss="modal" aria-hidden="true">&times;</button>
        </div>
        <div class="modal-body">
          <input type="hidden" id="id_u" name="id" class="form-control" required>
          <div class="form-group">
            <label>Name</label>
            <input type="text" id="name_u" name="name" class="form-control" required>
          </div>
          <div class="form-group">
            <label>Category</label>
            <select name="category" id="category_u" class="form-control" required>
                <option disabled selected value> -- Select a Category -- </option>
                <option value="electronics">Electronics</option>
                <option value="fashion">Fashion</option>
                <option value="supermarket">Supermarket</option>
                <option value="toys">Toys</option>
            </select>
          </div>
          <div class="form-group">
            <label>Description</label><br />
            <textarea name="descprition" id="description_u" rows="4" cols="30" required></textarea>
          </div>
          <div class="form-group">
            <label>Price</label>
            <input type="text" id="price_u" name="price" class="form-control" required>
          </div>
          <div class="form-group">
            <label>Quantity</label>
            <input type="number" id="quantity_u" name="quantity" class="form-control" required>
          </div>
          <div class="form-group">
            <label>Image</label>
            <input type="file" id="image_u" name="image" class="form-control" required>
          </div>
        </div>
        <div class="modal-footer">
        <input type="hidden" value="2" name="type">
          <input type="button" class="btn btn-default" data-dismiss="modal" value="Cancel">
          <button type="button" class="btn btn-info" id="update">Update</button>
        </div>
      </form>
    </div>
  </div>
</div>

<!-- Delete Modal -->

<div id="deleteProductModal" class="modal fade">
  <div class="modal-dialog">
    <div class="modal-content">
      <form>

        <div class="modal-header">
          <h4 class="modal-title">Delete Product</h4>
          <button type="button" class="close" data-dismiss="modal" aria-hidden="true">&times;</button>
        </div>
        <div class="modal-body">
          <input type="hidden" id="id_d" name="id" class="form-control">
          <p>Are you sure you want to delete this record?</p>
          <p class="text-warning"><small>This action cannot be undone.</small></p>
        </div>
        <div class="modal-footer">
          <input type="button" class="btn btn-default" data-dismiss="modal" value="Cancel">
          <button type="button" class="btn btn-danger" id="delete">Delete</button>
        </div>
      </form>
    </div>
  </div>
</div>



</body>
</html>
