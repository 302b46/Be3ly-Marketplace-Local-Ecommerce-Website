<?php
include '../database-connection.php';

//--------------------------------ORDERS SEARCH--------------------------------//
$search_result = '';
if(isset($_POST["query"]))
{
 $search = mysqli_real_escape_string($conn, $_POST["query"]);
 $query = "
  SELECT * FROM orders
  WHERE id LIKE '%".$search."%'
  OR customer LIKE '%".$search."%'
  OR product LIKE '%".$search."%'
  OR quantity LIKE '%".$search."%'
  OR totalCost LIKE '%".$search."%'
  OR purchaseDate LIKE '%".$search."%'
 ";
}
else
{
 $query = "
  SELECT * FROM orders ORDER BY id
 ";
}
$result = mysqli_query($conn, $query);
if(mysqli_num_rows($result) > 0)
{
 $search_result .= '
  <h2>Order History</h2>
   <table class="table table-hover">
    <tr>
     <th>ID</th>
     <th>Customer</th>
     <th>Product</th>
     <th>Quantity</th>
     <th>Total Cost</th>
     <th>Purchase Date</th>
    </tr>
 ';
 while($row = mysqli_fetch_array($result))
 {
  $search_result .= '
   <tr>
    <td>'.$row["id"].'</td>
    <td>'.$row["customer"].'</td>
    <td>'.$row["product"].'</td>
    <td>'.$row["quantity"].'</td>
    <td>'.$row["totalCost"].'</td>
    <td>'.$row["purchaseDate"].'</td>
   </tr>
  ';
 }
 echo $search_result;
}
else
{
 echo ' <h3>Order Not Found </h3>';
}

//--------------------------------CUSTOMERS SEARCH--------------------------------//




?>
