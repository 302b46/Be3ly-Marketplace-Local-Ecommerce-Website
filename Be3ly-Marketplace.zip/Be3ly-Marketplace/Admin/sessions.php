<?php
$Username=$_SESSION['Username'];
$sql = "SELECT * FROM user WHERE Username='$Username'";
$query = $conn->query($sql);
$total=mysqli_num_rows($query);
$row=$query->fetch_assoc();
?>
