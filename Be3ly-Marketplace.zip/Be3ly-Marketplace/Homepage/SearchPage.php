<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Product</title>
    <link href="logoFavion.png" type="image/png" rel="shortcut icon"> 

<!--Boostrap CDN-->
<link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@4.5.3/dist/css/bootstrap.min.css" integrity="sha384-TX8t27EcRE3e/ihU7zmQxVncDAy5uIKz4rEkgIXeMed4M0jlfIDPvg6uqKI2xXr2" crossorigin="anonymous">
<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/css/bootstrap.min.css">
  
<!--Font Awesome CDN-->
<script src="https://kit.fontawesome.com/ba83dadc75.js" crossorigin="anonymous">
</script>

<!--Slick Slider-->
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/slick-carousel/1.9.0/slick.min.css" integrity="sha512-yHknP1/AwR+yx26cB1y0cjvQUMvEa2PFzt1c9LlS4pRQ5NOTZFWbhBig+X9G9eYW/8m0/4OXNx8pxJ6z57x0dw==" crossorigin="anonymous" />
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/slick-carousel/1.9.0/slick-theme.min.css" integrity="sha512-17EgCFERpgZKcm0j0fEq1YCJuyAWdz9KUtv1EjVuaOz8pDnh/0nZxmU6BBXwaaxqoi9PQXnRWqlcDB027hgv9A==" crossorigin="anonymous" />

<!--Custom Stylesheet-->
<link rel="stylesheet" href="stylephp.css">

<!-- session start to read id of product to rating page -->
<?php 
session_start();
?>


</head>
<body>

<!-- reading products from database adminproducts -->
<?php

//trial ignore it
/*$idofproductSession = $_SESSION['id'];

echo  $idofproductSession; */

$servername = "localhost";
$username = "root";
$password = "";
$dbname = "be3ly";

// Create connection
$conn = new mysqli($servername, $username, $password, $dbname);
// Check connection
if ($conn->connect_error) {
  die("Connection failed: " . $conn->connect_error);
}

$ID=$_GET["id"]; 



$sql = "SELECT * FROM product WHERE id=$ID";
$result = $conn->query($sql);

if ($result->num_rows > 0) {
    while($row = $result->fetch_assoc()) {
      $idofproduct=$row["id"];
      $nameofproduct=$row["name"];
      $pictureofproduct=$row["image"];
      $priceofproduct=$row["price"];
      $descriptionofproduct=$row["description"];
      $categoryofproduct=$row["category"];
      
    }
}
else {
    echo "0 results";
  }


  
?>

    <!--Header-->
<header>
<div class="container">
    <div class="row">
        <div class="col-12"> <!--12 is the column width-->
            <div class="btn-group">
                
            </div>
        </div>
        <div class="col-13 text-left" onclick="location.href='http://localhost/WebProject/js/HomePagePHP.php';" style="cursor: pointer;"  >
            <h1 class="my-site-title"  >
                <img   src="logo1.png" alt="Logo" width="170px" height="70px"  >
            </h1>
        </div>
        
        <div class="col-12 text-right">
            <p class="header-links">
                <a href="#" class="px-2">Sign In</a>
                <a href="#" class="px-1">Create an Account</a>
            </p>
        </div>
    </div>
</div>

<div class="container-fluid p-0">
    <nav class="navbar navbar-expand-lg navbar-light bg-light">
      <!-- edit 1  -->
      <div class="dropdown">
        <button class="btn btn-secondary dropdown-toggle" class="navbar-brand" href="#" type="button" id="dropdownMenuButton" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
          Categories
        </button>
        <div class="dropdown-menu" aria-labelledby="dropdownMenuButton">
          <a class="dropdown-item" href="electronics.php">Electronics</a>
          <a class="dropdown-item" href="mobiles.php">Mobiles</a>
          <a class="dropdown-item" href="fashion.php">Fashion</a>
          <a class="dropdown-item" href="supermarket.php">Supermarket</a>
          <a class="dropdown-item" href="toys.php">Toys</a>
        </div>

      </div>
        <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarNav" aria-controls="navbarNav" aria-expanded="false" aria-label="Toggle navigation">
          <span class="navbar-toggler-icon"></span>
        </button>
        <div class="collapse navbar-collapse" id="navbarNav">
          <ul class="navbar-nav">
            <li class="nav-item active">
              <a class="nav-link" href="electronics.php">Electronics<span class="sr-only">(current)</span></a>
            </li>
            <li class="nav-item">
              <a class="nav-link" href="mobiles.php">Mobiles</a>
            </li>
            <li class="nav-item">
              <a class="nav-link" href="fashion.php">Fashion</a>
            </li>
            <li class="nav-item">
                <a class="nav-link" href="supermarket.php">Supermarket</a>
              </li>
              <li class="nav-item">
                <a class="nav-link" href="toys.php">Toys</a>
              </li>
            
          </ul>
        </div>



</header>
<main>

<?php

$id=0;

$id=$_GET["id"];

$sql2 = "SELECT * FROM ratingproduct WHERE ratingProduct=$id";
$result2 = $conn->query($sql2);

$idofproduct2= array();
$customername= array();
$customerEmail=array();
$ratingNumStar=array(); //number of stars
$categoryofproductRate=array(); //category of product
$productID=array(); //id of product
$ratingText=array();
$m=0;
$index=0;

if ($result2->num_rows > 0) {
    while($row = $result2->fetch_assoc()) {
      $idofproduct2[$m]=$row["id"];
      $customername[$m]=$row["customerName"];
      $customerEmail[$m]=$row["Email"];  
      $ratingText[$m]=$row["ratingText"];
      $ratingNumStar[$m]=$row["ratingNum"];  //number of stars
      $categoryofproductRate[$m]=$row["categoryProduct"];  //category of product
      $productID[$m]=$row["ratingProduct"]; //id of product
      $m++;
    }
}
else {
    //echo "0 results";
  }

 $index=$m;  //echo $index;
  $conn->close();

?>



<div class="container" id="product-section">
  <div class="row">
   <div class="col-md-6">
       <h2> <b> <?php echo $nameofproduct; ?> </b> </h2>

   <img src="data:image/jpeg;base64,<?php echo base64_encode($pictureofproduct); ?>" width="400px" height="400px" />
   </div>
   <div class="col-md-6">
    <br><h2 style="color:Red;"> <b> <?php echo $priceofproduct; echo "&nbsp;";echo "EGP"; ?> </b></h2>
    <h6>  All prices include VAT  </h6>
    <hr>
    <!-- if conditions to read id from database and display correspondant category name  -->
   <?php if($categoryofproduct==2){ $display="Fashion"; } ?>
   <?php if($categoryofproduct==1){ $display="Electronics"; } ?>
   <?php if($categoryofproduct==3){ $display="Supermarket"; } ?>
   <?php if($categoryofproduct==4){ $display="Toys"; } ?>
   <?php if($categoryofproduct==5){ $display="Mobiles"; } ?>

    <h5><b> Category: </b>&nbsp <?php echo $display; ?> </h5>  <br>
    <h5><b> Description: </b> &nbsp  <?php echo $descriptionofproduct; ?> </h5> <br>
    <a href="#" class="btn btn-info btn-lg"style="background-color:black; width: 250px;">
          <span class="glyphicon glyphicon-shopping-cart" style="color:white;" ></span> Go To Cart
        </a> 
        <br> <br> 
        <a href="ratingPage.php?category=<?php echo  $categoryofproduct;?>&id=<?php echo $id;?>" class="btn btn-info btn-lg"style="background-color:black; width: 250px;">
          <i class="fas fa-star"></i>&nbsp; Rate this product
        </a> 
   </div>
  </div><!-- end row -->
 </div><!-- end container -->
<br>

 <div class="container" id="product-section">
  <div class="row">
   <div class="col-md-6" >
      <h2><b> Reviews and Rates </b></h2> <hr>
     <?php   for($p=0;$p<$index;$p++){  ?>
      <h3 style="color:#191970;"> <b> <?php echo $customername[$p]; ?> </b></h3>  <!-- customer name --> 
     
      <h5 style="color:green;"> <i> <?php echo $customerEmail[$p]; ?> </i></h5>
      <h5 style="color:orange;">  
      <!-- loop to display the checked stars -->
      <?php for($w=0;$w<5;$w++){
      if($w<=5){ 
        for($q=0;$q<$ratingNumStar[$p];$q++){ ?>
      <i class="fas fa-star"></i> 
      <?php } break;}
        else{   ?><i class="fars fa-star"></i><?php } } ?>
       <i style="color:black;"> <?php echo$ratingNumStar[$p]; ?> out of 5</i></h5><!-- star rate -->

      <p style="color:black;">   <?php echo $ratingText[$p]; ?></p> <!-- full review --> <br>
      <?php } ?>
   </div>
   <div class="col-md-6">
    <!-- law 3ayza thoty haga fl gamb -->
 
    
    
   </div>
  </div><!-- end row -->
 </div><!-- end container -->

</main>


<br> <br>
<!-- Footer -->
<footer class="bg-light text-center text-lg-start">
  <!-- Grid container -->
  <div class="container p-4">
    <!--Grid row-->
    <div class="row">
      <!--Grid column-->
      <div class="col">
        <h5 class="text-uppercase"> <b>We're here to help</b></h5>

        <!-- *edited* help centre div clickable go to write complains to send to our database -->
        <i class="fas fa-info-circle" style="position: relative; left: -10px;"></i> 
        <a href="#">egypt@be3ly.com</a>  <br> <br>
        <div> <a href="#"><button style="background-color: #C0C0C0; color: black; border: 20px solid #C0C0C0; ">
         <i class="fas fa-hands-helping"></i> <h6"><b>Help centre</b> </h6> <br> <p> Have a question or an issue?<br> We are here to help </p>  </button><a> </div>
       <br> <br> <b>Follow us in:</b>
       <a href="#" class="fa fa-facebook"></a>
        <a href="#" class="fa fa-twitter"></a>
        <a href="#" class="fa fa-instagram"></a>
        <a href="#" class="fa fa-linkedin"></a> <br> <br>
        Download our app: 
        <a href="#" class="fa fa-android"></a>
        <a href="#" class="fa fa-apple"></a>
      </div>
      <!--Grid column-->


      
      <!--Grid column-->
      <div class="col">
        <a href="mobiles.php" class="text-uppercase"> <b>Mobiles</b></a>

        <ul class="list-unstyled mb-0">
          <li>
            <a href="mobiles.php" class="text-dark">Mobiles</a>
          </li>
          <li>
            <a href="mobiles.php" class="text-dark">Tablets</a>
          </li>
          <li>
            <a href="mobiles.php" class="text-dark">chargers</a>
          </li>
          <li>
            <a href="mobiles.php" class="text-dark">headphones</a>
          </li>
          <li>
            <a href="mobiles.php" class="text-dark">USB cables</a>
          </li>
          <li>
            <a href="mobiles.php" class="text-dark">Mobiles accesories</a>
          </li>
        </ul>
<br>
        <a href="electronics.php" class="text-uppercase"> <b>Electronics</b></a>

<ul class="list-unstyled mb-0">
  <li>
    <a href="electronics.php" class="text-dark">Laptops</a>
  </li>
  <li>
    <a href="electronics.php" class="text-dark">Tablets</a>
  </li>
  <li>
    <a href="electronics.php" class="text-dark">printers</a>
  </li>
  <li>
    <a href="electronics.php" class="text-dark">TV's</a>
  </li>
  <li>
    <a href="electronics.php" class="text-dark">Camera</a>
  </li>
  <li>
    <a href="electronics.php" class="text-dark">Video Games</a>
  </li>
</ul>

      </div>
      <!--Grid column-->

      <!--Grid column-->
      <div class="col">
        <a href="fashion.php" class="text-uppercase mb-0"><b>Fashion</b></h5>

        <ul class="list-unstyled">
          <li>
            <a href="fashion.php" class="text-dark">Women's wear</a>
          </li>
          <li>
            <a href="fashion.php" class="text-dark">Men's wear</a>
          </li>
          <li>
            <a href="fashion.php" class="text-dark">Kids wear</a>
          </li>
          <li>
            <a href="fashion.php" class="text-dark">Eye Wear</a>
          </li>
          <li>
            <a href="fashion.php" class="text-dark">Watches</a>
          </li>
          <li>
            <a href="fashion.php" class="text-dark">bags & luggage</a>
          </li>
        </ul>

        <a href="supermarket.php" class="text-uppercase mb-0"><b>Supermarket</b></h5>

<ul class="list-unstyled">
  <li>
    <a href="supermarket.php" class="text-dark">pasta & rice</a>
  </li>
  
  <li>
    <a href="supermarket.php" class="text-dark">food</a>
  </li>
  <li>
    <a href="supermarket.php" class="text-dark">cooking essentials</a>
  </li>
  
  </li>
</ul>

      </div>

      <div class="col">
        <a href="toys.php" class="text-uppercase mb-0"><b>Toys</b></h5>

        <ul class="list-unstyled">
          <li>
            <a href="toys.php" class="text-dark">trampoline</a>
          </li>
          <li>
            <a href="toys.php" class="text-dark">dolls</a>
          </li>
          <li>
            <a href="toys.php" class="text-dark">cars</a>
          </li>
          <li>
            <a href="toys.php" class="text-dark">activities</a>
          </li>
         
          
        </ul>
<br> <br>
        <a class="text-uppercase mb-0"><b>MY ACCOUNT</b></h5>

<ul class="list-unstyled">
  <li>
    <a href="#" class="text-dark">sign in</a>
  </li>
  <li>
    <a href="#" class="text-dark">create an account</a>
  </li>
  
</ul>


      </div>

      

      <!--Grid column-->
    </div>
    <!--Grid row-->
  </div>

  
</div>

  <!-- Grid container -->

  <!-- Copyright -->
  <div class="text-center p-3" style="background-color: rgba(0, 0, 0, 0.2)">
    © 2020 Copyright:
    <a class="text-dark" href="#">Be3ly.com</a>
  </div>
  <!-- Copyright -->
</footer>
<!-- Footer -->

  <script src="https://code.jquery.com/jquery-3.5.1.slim.min.js" integrity="sha384-DfXdz2htPH0lsSSs5nCTpuj/zy4C+OGpamoFVy38MVBnE+IbbVYUew+OrCXaRkfj" crossorigin="anonymous"></script>
  <script src="https://cdn.jsdelivr.net/npm/bootstrap@4.5.3/dist/js/bootstrap.bundle.min.js" integrity="sha384-ho+j7jyWK8fNQe+A12Hb8AhRq26LrZ/JpcUGGOn+Y7RsweNrtN/tE3MoK7ZeZDyx" crossorigin="anonymous">
  </script>
  <script src="https://cdnjs.cloudflare.com/ajax/libs/slick-carousel/1.9.0/slick.min.js" integrity="sha512-HGOnQO9+SP1V92SrtZfjqxxtLmVzqZpjFFekvzZVWoiASSQgSr4cw9Kqd2+l8Llp4Gm0G8GIFJ4ddwZilcdb8A==" crossorigin="anonymous"></script>
  <script src="D:college/Semester 5/Web Dev/project/farida's work/Be3ly/js/main.js"></script>
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>

  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/js/bootstrap.min.js"></script>
</body>
</html>