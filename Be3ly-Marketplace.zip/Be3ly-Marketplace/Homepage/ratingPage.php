<?php
include "../header.php";
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Product</title>
    <link href="logoFavion.png" type="image/png" rel="shortcut icon">

<!--Boostrap CDN-->
<link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@4.5.3/dist/css/bootstrap.min.css" integrity="sha384-TX8t27EcRE3e/ihU7zmQxVncDAy5uIKz4rEkgIXeMed4M0jlfIDPvg6uqKI2xXr2" crossorigin="anonymous">
<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/css/bootstrap.min.css">

<!--Font Awesome CDN-->
<script src="https://kit.fontawesome.com/ba83dadc75.js" crossorigin="anonymous">
</script>

<!--Slick Slider-->
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/slick-carousel/1.9.0/slick.min.css" integrity="sha512-yHknP1/AwR+yx26cB1y0cjvQUMvEa2PFzt1c9LlS4pRQ5NOTZFWbhBig+X9G9eYW/8m0/4OXNx8pxJ6z57x0dw==" crossorigin="anonymous" />
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/slick-carousel/1.9.0/slick-theme.min.css" integrity="sha512-17EgCFERpgZKcm0j0fEq1YCJuyAWdz9KUtv1EjVuaOz8pDnh/0nZxmU6BBXwaaxqoi9PQXnRWqlcDB027hgv9A==" crossorigin="anonymous" />

<!--Custom Stylesheet-->
<link rel="stylesheet" href="stylephp.css?v=<?php echo time(); ?>">   <!-- da ely 5ala ye2ra el ta3dilat mn el css file beta3y -->

<!-- session from product index page to read id -->

</head>
<body>


<main>

<div class="container" id="product-section">
  <div class="row">
   <div class="col-md-6">
       <h1> <b> Rating & Reviews </b> </h1>

       <form method ="post" >
        Name : <input class="ratebar" type="text" name="namename">   <br> <br>
        Email : <input class="ratebar" type="text" name="mail">  <br> <br>
        Rating : <input class="ratebar" type="text" name="rateComment" > <br> <br>
        Stars : <?php for($te=1;$te<6;$te++){ ?>
         <input type="checkbox" value = "<?php echo $te; ?> " name = "checkbox[]">
         <?php }?> &nbsp; <i>Rate product out of 5</i>
         <br> <br>
        <input type="submit" id="submit" class="submitbtn" name="submit" >
        </form>

   </div>
   <div class="col-md-6">
   </div>
  </div><!-- end row -->
 </div><!-- end container -->



<?php

//echo $count;

if(isset($_POST["submit"])){


  $checked_arr = $_POST['checkbox'];
  //echo $_POST['checkbox']; echo "<br>";
  $rateStar = count($checked_arr); //echo count($checked_arr);
  //echo "There are ".$rateStar." checkboxe(s) are checked"; echo "<br>";

    $servername= "localhost";
    $username="root";
    $password="";
    $dbname="be3ly";


    $conn = new mysqli($servername, $username, $password, $dbname);
    // Check connection
    if ($conn->connect_error) {
      die("Connection failed: " . $conn->connect_error);
    }

    $nameC=$_POST["namename"];  //customerName
    $mailC=$_POST["mail"];  //Email
    $rateC=$_POST["rateComment"];  //ratingText
    $id=$_GET["id"];  //id of product (ratingProduct)
    $category=$_GET["category"];  //id of category (categoryProduct)

    //echo $nameC; echo "<br>";
    //echo $mailC;echo "<br>";

    $sql="INSERT into ratingproduct (Email,customerName,ratingText,ratingNum,ratingProduct,categoryProduct)
    VALUES ('".$_POST['mail']."','".$_POST['namename']."','".$_POST['rateComment']."',$rateStar,'".$_GET["id"]."','".$_GET["category"]."')";
    $result = $conn->query($sql);

    if ($result === TRUE) {
      echo "<br><h3>thank you for your rating! it helps us to improve :)</h3>";
    } else {
      echo "Error: " . $sql . "<br>" . $conn->error;
    }



}

?>

</main>

<br> <br>



  <script src="https://code.jquery.com/jquery-3.5.1.slim.min.js" integrity="sha384-DfXdz2htPH0lsSSs5nCTpuj/zy4C+OGpamoFVy38MVBnE+IbbVYUew+OrCXaRkfj" crossorigin="anonymous"></script>
  <script src="https://cdn.jsdelivr.net/npm/bootstrap@4.5.3/dist/js/bootstrap.bundle.min.js" integrity="sha384-ho+j7jyWK8fNQe+A12Hb8AhRq26LrZ/JpcUGGOn+Y7RsweNrtN/tE3MoK7ZeZDyx" crossorigin="anonymous">
  </script>
  <script src="https://cdnjs.cloudflare.com/ajax/libs/slick-carousel/1.9.0/slick.min.js" integrity="sha512-HGOnQO9+SP1V92SrtZfjqxxtLmVzqZpjFFekvzZVWoiASSQgSr4cw9Kqd2+l8Llp4Gm0G8GIFJ4ddwZilcdb8A==" crossorigin="anonymous"></script>
  <script src="D:college/Semester 5/Web Dev/project/farida's work/Be3ly/js/main.js"></script>
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>

  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/js/bootstrap.min.js"></script>
</body>
</html>
<?php
include "../footer.php";
 ?>
