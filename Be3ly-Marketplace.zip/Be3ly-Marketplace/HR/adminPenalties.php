<?php include "hrDashboard.php"?>
<html>
<head>
  <link rel="stylesheet" type="text/css" href="../CSS/tables.css">

  <!-- BOOTSTRAP TABLE -->
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/css/bootstrap.min.css">

</head>
<title>Admins</title>
<body>

<div class="container">
  <button type="button" style="border-radius:10px;margin-left:980px;" class="btn btn-primary" onclick="document.location='viewPenalties.php'">View Admins With A Penalty</button>

  <h2>Admins</h2>

  <table class="table table-hover">
    <thead>
      <tr>
        <th>ID</th>
        <th>Name</th>
        <th>Username</th>
        <th>Password</th>
        <th>Email</th>
        <th>Action</th>
      </tr>
    </thead>
    <tbody>
    <?php

    $sql ="SELECT * FROM user WHERE UserType=1";
    $result=mysqli_query($conn,$sql);

    while($row=mysqli_fetch_assoc($result)){

      ?>
      <tr id="<?php echo $row["id"]; ?>">

        <!-- DISPLAYING ADMINS -->
        <td><?php echo $row["id"]?></td>
        <td><?php echo $row["Name"]?></td>
        <td><?php echo $row["Username"]?></td>
        <?php $admin=$row['Username'];?>
        <td><?php echo $row["Password"]?></td>
        <td><?php echo $row["Email"]?></td>


          <form method="post">

         <?php echo "<td><input type='submit'style='border-radius:10px;' value='Add Penalty'name='addPenalty'class='btn btn-danger'></td>";?>
          </form>



      </tr>
      <?php
      }
      ?>
    </tbody>
  </table>
</div>

<?php

//------------------------------------------------ADD PENALTY------------------------------------------------//

if(isset($_POST['addPenalty']))
{
  $hr=$_SESSION['Username'];


  $deletePenalty = "INSERT INTO penalty (hr,admin)
                 VALUES ('$hr','$admin')";


   if (mysqli_query($conn, $deletePenalty)) {
       echo "<script>alert('Penalty Added Successfully!');</script>";
       header("refresh:1; url=adminPenalties.php");

     }
     else {
       echo "Error: " . $deletePenalty . "<br>" . mysqli_error($conn);
     }
     mysqli_close($conn);


}

?>


</body>
</html>
