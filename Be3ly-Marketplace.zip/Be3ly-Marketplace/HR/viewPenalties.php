<?php include "hrDashboard.php"?>
<html>
<title>View Penalties</title>
<body>
  <div class="container">
    <button style="border-radius:10px;margin-left:980px;"class=" btn btn-primary glyphicon glyphicon-arrow-left" title="Go Back" onclick="history.back()"></button>
    <h2>Penalties</h2>

    <table class="table table-hover">
      <thead>
        <tr>
          <th>ID</th>
          <th>Admin</th>
          <th>Action</th>
        </tr>
      </thead>
      <tbody>

<?php

  $penalty_query="SELECT * FROM penalty";
  $penalty=mysqli_query($conn,$penalty_query);
  while($row=mysqli_fetch_assoc($penalty))
  {
  ?>
    <tr id="<?php echo $row["id"]; ?>">
      <td><?php echo $row["id"];?></td>
      <td><?php echo $row["admin"];?></td>
      <?php $admin=$row["admin"];?>
      <form method="post">
        <?php echo "<td><input type='submit'style='border-radius:10px;' value='Delete Penalty'name='deletePenalty'class='btn btn-danger'></td>";?>
      </form>
  </tr>
    <?php
  }
?>
</div>
</tbody>
</table>

<?php
//------------------------------------------------DELETE PENALTY------------------------------------------------//

  if(isset($_POST['deletePenalty']))
  {




    $deletePenalty = "DELETE FROM penalty WHERE admin='$admin'";


     if (mysqli_query($conn, $deletePenalty)) {
         echo "<script>alert('Penalty Deleted Successfully!');</script>";
         header("refresh:1; url=viewPenalties.php");


       }

       else {
         echo "Error: " . $deletePenalty . "<br>" . mysqli_error($conn);
       }
       mysqli_close($conn);


  }

?>

</body>
</html>
