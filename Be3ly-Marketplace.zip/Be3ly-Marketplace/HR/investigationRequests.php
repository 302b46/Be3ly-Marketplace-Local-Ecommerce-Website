<?php include "hrDashboard.php"?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
	  <!-- BOOTSTRAP TABLE -->
   <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/css/bootstrap.min.css">
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/js/bootstrap.min.js"></script>
   <title>HR</title>

	<link rel="stylesheet" href="../CSS/messages.css">
</head>
<body>

<?php

//---------------------Reading Requests From Database---------------------//

$sql = "SELECT * FROM investigationrequest";
$result = $conn->query($sql);

if ($result->num_rows > 0) {

	?>
	<div class="container">
	<h1 id='h1'><?php echo"Investigation Requests";?></h1>
  <table class="table"><tr><th><?php echo"Request ID";?></th><th><?php echo "Auditor username";?></th><th><?php echo "Admin username";?></th><th><?php echo"Request statement";?></th></tr>
  <?php
  while($row = $result->fetch_assoc()) {
	  $admin_query = "SELECT Username FROM user WHERE id=" . $row['admin'];
                $admin_info = $conn->query($admin_query);
                $admin_data = $admin_info->fetch_assoc();

				$auditor_query = "SELECT Username FROM user WHERE id=" . $row['auditor'];
                $auditor_info = $conn->query($auditor_query);
                $auditor_data = $auditor_info->fetch_assoc();
				?>

    <tr><td><?php echo $row["id"];?></td><td><?php echo $auditor_data["Username"]; ?></td><td><?php echo $admin_data["Username"];?></td><td><?php echo $row["requestStatement"];?></td></tr>

  <?php
  }
  ?>

  </table>
  </div>
  <br>

<?php
}
else {
  echo "0 results";
}


?>

	</body>
	</html>
