<?php include "hrDashboard.php"?>

<html>
<title>Profile</title>
<body>

  <div class="container">
    <div class="main-body">

          <!-- "Admin Profile" gray tab on top -->
          <nav aria-label="breadcrumb" class="main-breadcrumb">
            <ol class="breadcrumb">
            <b style="font-size:30px;"> <li class="breadcrumb-item active" aria-current="page">HR Profile</li></b>
            </ol>
          </nav>
          <br />

          <!-- PROFILE PICTURE AREA -->

          <div class="row gutters-sm">
            <div class="col-md-4 mb-3">
              <div class="card">
                <div class="card-body">
                  <div class="d-flex flex-column align-items-center text-center">
                    <img src="https://bootdey.com/img/Content/avatar/avatar7.png" alt="Admin" class="rounded-circle" width="150">
                    <div class="mt-3">
                      <h4><?php echo$row['Name'];?></h4>
                      <p class="text-secondary mb-1">Be3ly Marketplace Admin</p>
                    </div>
                  </div>
                </div>
              </div>
            </div>

            <!-- PROFILE INFO AREA -->
            <div class="col-md-8">
              <div class="card mb-3">
                <div class="card-body">
                  <div class="row">
                    <div class="col-sm-3">
                      <h6 class="mb-0">Full Name</h6>
                    </div>
                    <div class="col-sm-9 text-secondary">
                      <?php echo $row['Name'];?>
                    </div>
                  </div>
                  <hr>
                  <div class="row">
                    <div class="col-sm-3">
                      <h6 class="mb-0">Username</h6>
                    </div>
                    <div class="col-sm-9 text-secondary">
                      <?php echo $row['Username'];?>
                    </div>
                  </div>
                  <hr>
                  <div class="row">
                    <div class="col-sm-3">
                      <h6 class="mb-0">Password</h6>
                    </div>
                    <div class="col-sm-9 text-secondary">
                      <?php echo $row['Password'];?>
                    </div>
                  </div>
                  <hr>
                  <div class="row">
                    <div class="col-sm-3">
                      <h6 class="mb-0">Email</h6>
                    </div>
                    <div class="col-sm-9 text-secondary">
                      <?php echo $row['Email'];?>
                    </div>
                  </div>
                  <hr>
                  </div>
                </div>
              </div>

              </div>
            </div>
          </div>

</body>
</html>
