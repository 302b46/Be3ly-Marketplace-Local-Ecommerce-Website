<?php include "auditorDashboard.php"?>
<html>
<title>Homepage</title>
<body>
  <?php
    $Username=$_SESSION['Username'];
    $sql = "SELECT * FROM user WHERE Username='$Username'";
    $query = $conn->query($sql);
    $total=mysqli_num_rows($query);
    $row=$query->fetch_assoc();

  ?>
<h2 style="padding-left:20px; padding-top:20px;">Welcome, <?php echo $row['Name'];?></h2>

</body>
</html>
