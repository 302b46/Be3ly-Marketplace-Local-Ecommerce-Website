<?php include "auditorDashboard.php"?>
<html>
<title>Customers</title>

<head>
  <!-- BOOTSTRAP TABLE -->
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/css/bootstrap.min.css">


</head>
<body>

<div class="container">
  <h2>&nbsp; Customers</h2>
  <table class="table table-hover">
    <thead>
      <tr>
        <th>ID</th>
        <th>Name</th>
        <th>Username</th>
        <th>Email</th>
        <th>Action</th>
      </tr>
    </thead>
    <?php

    $sql ="SELECT * FROM user WHERE UserType=4";
    $result=mysqli_query($conn,$sql);
    if (mysqli_num_rows($result)>0){

      while($row=mysqli_fetch_assoc($result)){

                echo "<td>" . $row['id'] . "</td> &nbsp";
                $customer=$row['id'];
               echo "<td>" . $row['Name'] . "</td> &nbsp";

               echo "<td>" . $row['Username'] . "</td> &nbsp";



               echo "<td>" . $row['Email'] . "</td> &nbsp";
               ?>
               <form method="post">

              <?php echo "<td><input type='submit'style='border-radius:10px;' value='Send Survey'name='sendSurvey'class='btn btn-dark'></td>";?>
               </form>
              <?php
               echo "</tr>";

      }


    }

     ?>
    </table>

     <button type="button"style="background-color: #293a6a;border-radius:10px; flex:right;" class="btn btn-info" onclick="document.location='survey.php'">View Survey</button>

     <!-- SENDING SURVEYS AS A LINK IN A MESSAGE TO SELECTED CUSTOMERS -->
     <?php
     if(isset($_POST['sendSurvey']))
     {
       // sends current date
       $messageDate=date("Y/m/d");
       $auditor=$_SESSION['id'];
       $message="Dear customer, kindly fill out this survey, your feedback is important to us. :)<br />
                    http://localhost/Be3ly-Marketplace/Auditor/survey.php";

       $send = "INSERT INTO messages (sender,receiver,messageContent,image, messageDate)
                VALUES ('$auditor','$customer','$message',NULL,'$messageDate')";

       // $result=mysqli_query($conn,$send);

       	if (mysqli_query($conn, $send)) {
       			echo "<script>alert('Survey Sent Successfully!');</script>";
       		}
       		else {
       			echo "Error: " . $send . "<br>" . mysqli_error($conn);
       		}
       		mysqli_close($conn);


     }

     ?>

</div>
</body>
</html>
