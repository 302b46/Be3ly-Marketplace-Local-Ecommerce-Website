<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Survey</title>
  <!-- CSS only -->
  <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/5.0.0-alpha1/css/bootstrap.min.css" integrity="sha384-r4NyP46KrjDleawBgD5tp8Y7UzmLA05oM1iAEQ17CSuDqnUK2+k9luXQOfXJCJ4I" crossorigin="anonymous">
</head>
<body>
  <div class="container">
    <div class="row py-4">
      <div class="col">
        <div class="text-center">
          <h1>Be3ly Marketplace Survey</h1>
        </div>
      </div>
    </div>
    <div class="row justify-content-center">
      <div class="col-md-8 col-lg-6">
        <form action="surveyAnswers.php" method="post" id="survey" name="submitSurvey">
          <nav>
            <div class="nav nav-pills nav-fill" id="nav-tab" role="tablist">
              <a class="nav-link active" id="step1-tab" data-toggle="tab" href="#step1">Website</a>
              <a class="nav-link" id="step2-tab" data-toggle="tab" href="#step2">Products</a>
              <a class="nav-link" id="step3-tab" data-toggle="tab" href="#step3">Communication</a>
            </div>
          </nav>
          <br />
          <!-- THE WHOLE SURVEY DIV -->
          <div class="tab-content py-4" id="nav-tabContent">
            <!-- WEBSITE SURVEY -->
            <div class="tab-pane fade show active" id="step1">
              <h5>Q1) Overall Be3ly Marketplace website experience.</h5>
              <div class="mb-3">
                <input type="radio" name="ans1" class="form-check-input" id="field1" value="Very Good" required>
                <label class="form-check-label" for="field1">Very Good</label>&nbsp;
                <input type="radio" name="ans1" class="form-check-input" id="field1" value="Good" required>
                <label class="form-check-label" for="field1">Good</label>&nbsp;
                <input type="radio" name="ans1" class="form-check-input" id="field1" value="Neutral" required>
                <label class="form-check-label" for="field1">Neutral</label>&nbsp;
                <input type="radio" name="ans1" class="form-check-input" id="field1" value="Bad" required>
                <label class="form-check-label" for="field1">Bad</label>&nbsp;
                <input type="radio" name="ans1" class="form-check-input" id="field1" value="Very Bad" required>
                <label class="form-check-label" for="field1">Very Bad</label>
              </div><br />
              <h5>Q2) Be3ly Marketplace is easy to use.</h5>
              <div class="mb-3">
                <input type="radio" name="ans2" class="form-check-input" id="field2" value="Strongly Agree" required>
                <label class="form-check-label" for="field2">Strongly Agree</label>&nbsp;
                <input type="radio" name="ans2" class="form-check-input" id="field2" value="Agree" required>
                <label class="form-check-label" for="field2">Agree</label>&nbsp;
                <input type="radio" name="ans2" class="form-check-input" id="field2" value="Neutral" required>
                <label class="form-check-label" for="field2">Neutral</label>&nbsp;
                <input type="radio" name="ans2" class="form-check-input" id="field2" value="Disagree" required>
                <label class="form-check-label" for="field2">Disagree</label>&nbsp;
                <input type="radio" name="ans2" class="form-check-input" id="field2" value="Strongly Disagree" required>
                <label class="form-check-label" for="field2">Strongly Disagree</label>
              </div><br />
              <h5>Q3) Be3ly Marketplace is responsive.</h5>
              <div class="mb-3">
                <input type="radio" name="ans3" class="form-check-input" id="field3" value="Strongly Agree" required>
                <label class="form-check-label" for="field3">Strongly Agree</label>&nbsp;
                <input type="radio" name="ans3" class="form-check-input" id="field3" value="Agree" required>
                <label class="form-check-label" for="field3">Agree</label>&nbsp;
                <input type="radio" name="ans3" class="form-check-input" id="field3" value="Neutral" required>
                <label class="form-check-label" for="field3">Neutral</label>&nbsp;
                <input type="radio" name="ans3" class="form-check-input" id="field3" value="Disagree" required>
                <label class="form-check-label" for="field3">Disagree</label>&nbsp;
                <input type="radio" name="ans3" class="form-check-input" id="field3" value="Strongly Disagree" required>
                <label class="form-check-label" for="field3">Strongly Disagree</label>
              </div><br />
            </div>
            <!-- PRODUCT SURVEY -->
            <div class="tab-pane fade" id="step2">
              <h5>Q1) Overall Product Quality</h5>
              <div class="mb-3">
                <input type="radio" name="ans4" class="form-check-input" id="field4" value="Very Good" required>
                <label class="form-check-label" for="field4">Very Good</label>&nbsp;
                <input type="radio" name="ans4" class="form-check-input" id="field4" value="Good" required>
                <label class="form-check-label" for="field4">Good</label>&nbsp;
                <input type="radio" name="ans4" class="form-check-input" id="field4" value="Neutral" required>
                <label class="form-check-label" for="field4">Neutral</label>&nbsp;
                <input type="radio" name="ans4" class="form-check-input" id="field4" value="Bad" required>
                <label class="form-check-label" for="field4">Bad</label>&nbsp;
                <input type="radio" name="ans4" class="form-check-input" id="field4" value="Very Bad" required>
                <label class="form-check-label" for="field4">Very Bad</label>
              </div><br />
              <h5>Q2) Product Variety</h5>
              <div class="mb-3">
                <input type="radio" name="ans5" class="form-check-input" id="field5" value="Very Good" required>
                <label class="form-check-label" for="field5">Very Good</label>&nbsp;
                <input type="radio" name="ans5" class="form-check-input" id="field5" value="Good" required>
                <label class="form-check-label" for="field5">Good</label>&nbsp;
                <input type="radio" name="ans5" class="form-check-input" id="field5" value="Neutral" required>
                <label class="form-check-label" for="field5">Neutral</label>&nbsp;
                <input type="radio" name="ans5" class="form-check-input" id="field5" value="Bad" required>
                <label class="form-check-label" for="field5">Bad</label>&nbsp;
                <input type="radio" name="ans5" class="form-check-input" id="field5" value="Very Bad" required>
                <label class="form-check-label" for="field5">Very Bad</label>
              </div><br />
              <h5>Q3) Product Prices Are Reasonable</h5>
              <div class="mb-3">
                <input type="radio" name="ans6" class="form-check-input" id="field6" value="Strongly Agree" required>
                <label class="form-check-label" for="field6">Strongly Agree</label>&nbsp;
                <input type="radio" name="ans6" class="form-check-input" id="field6" value="Agree" required>
                <label class="form-check-label" for="field6">Agree</label>&nbsp;
                <input type="radio" name="ans6" class="form-check-input" id="field6" value="Neutral" required>
                <label class="form-check-label" for="field6">Neutral</label>&nbsp;
                <input type="radio" name="ans6" class="form-check-input" id="field6" value="Disagree" required>
                <label class="form-check-label" for="field6">Disagree</label>&nbsp;
                <input type="radio" name="ans6" class="form-check-input" id="field6" value="Strongly Disagree" required>
                <label class="form-check-label" for="field6">Strongly Disagree</label>
              </div><br />
            </div>
            <!-- COMMUNICATION SURVEY -->
            <div class="tab-pane fade" id="step3">
              <h5>Q1) It was easy to ask for and get help when needed.</h5>
              <div class="mb-3">
                <input type="radio" name="ans7" class="form-check-input" id="field7" value="Strongly Agree" required>
                <label class="form-check-label" for="field7">Strongly Agree</label>&nbsp;
                <input type="radio" name="ans7" class="form-check-input" id="field7" value="Agree" required>
                <label class="form-check-label" for="field7">Agree</label>&nbsp;
                <input type="radio" name="ans7" class="form-check-input" id="field7" value="Neutral" required>
                <label class="form-check-label" for="field7">Neutral</label>&nbsp;
                <input type="radio" name="ans7" class="form-check-input" id="field7" value="Disagree" required>
                <label class="form-check-label" for="field7">Disagree</label>&nbsp;
                <input type="radio" name="ans7" class="form-check-input" id="field7" value="Strongly Disagree" required>
                <label class="form-check-label" for="field7">Strongly Disagree</label>
              </div><br />
              <h5>Q2) I received a fast response.</h5>
              <div class="mb-3">
                <input type="radio" name="ans8" class="form-check-input" id="field8" value="Strongly Agree" required>
                <label class="form-check-label" for="field8">Strongly Agree</label>&nbsp;
                <input type="radio" name="ans8" class="form-check-input" id="field8" value="Agree" required>
                <label class="form-check-label" for="field8">Agree</label>&nbsp;
                <input type="radio" name="ans8" class="form-check-input" id="field8" value="Neutral" required>
                <label class="form-check-label" for="field8">Neutral</label>&nbsp;
                <input type="radio" name="ans8" class="form-check-input" id="field8" value="Disagree" required>
                <label class="form-check-label" for="field8">Disagree</label>&nbsp;
                <input type="radio" name="ans8" class="form-check-input" id="field8" value="Strongly Disagree" required>
                <label class="form-check-label" for="field8">Strongly Disagree</label>
              </div><br />
              <h5>Q3) Admin communication was respectful and nice.</h5>
              <div class="mb-3">
                <input type="radio"name="ans9" class="form-check-input" id="field9" value="Strongly Agree" required>
                <label class="form-check-label" for="field9">Strongly Agree</label>&nbsp;
                <input type="radio"name="ans9" class="form-check-input" id="field9" value="Agree" required>
                <label class="form-check-label" for="field9">Agree</label>&nbsp;
                <input type="radio"name="ans9" class="form-check-input" id="field9" value="Neutral" required>
                <label class="form-check-label" for="field9">Neutral</label>&nbsp;
                <input type="radio"name="ans9" class="form-check-input" id="field9" value="Disagree" required>
                <label class="form-check-label" for="field9">Disagree</label>&nbsp;
                <input type="radio"name="ans9" class="form-check-input" id="field9" value="Strongly Disagree" required>
                <label class="form-check-label" for="field9">Strongly Disagree</label>
              </div><br />
            </div>
          </div>
          <div class="row justify-content-between">
            <div class="col-auto"><button type="button" class="btn btn-secondary" data-enchanter="previous">Previous</button></div>
            <div class="col-auto">
              <button type="button" class="btn btn-primary" data-enchanter="next">Next</button>
              <button type="submit" class="btn btn-primary" data-enchanter="finish" name="submitSurvey">Finish</button>
            </div>
          </div>
        </form>
      </div>
    </div>
  </div>

  <!-- JavaScript and dependencies -->
  <script src="https://cdn.jsdelivr.net/npm/popper.js@1.16.0/dist/umd/popper.min.js"></script>
  <script src="https://stackpath.bootstrapcdn.com/bootstrap/5.0.0-alpha1/js/bootstrap.min.js"></script>
  <script src="https://cdn.jsdelivr.net/npm/jquery@3.5.1/dist/jquery.min.js"></script>
  <script src="https://cdn.jsdelivr.net/npm/jquery-validation@1.19.2/dist/jquery.validate.min.js"></script>
  <script src="dist/enchanter.js"></script>
  <script>
    var surveyForm = $('#survey');
    var formValidate = surveyForm.validate({
      errorClass: 'is-invalid',
      errorPlacement: () => false
    });

    const wizard = new Enchanter('survey', {}, {
      onNext: () => {
        if (!surveyForm.valid()) {
          formValidate.focusInvalid();
          return false;
        }
      }
    });
  </script>
</body>
</html>
