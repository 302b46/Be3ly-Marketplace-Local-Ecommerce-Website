<?php include "../database-connection.php";
include "../Auditor/sessions.php";
?>

<?php
if(isset($_POST['submitSurvey']))
{

    $ans1=$_POST['ans1'];
    $ans2=$_POST['ans2'];
    $ans3=$_POST['ans3'];
    $ans4=$_POST['ans4'];
    $ans5=$_POST['ans5'];
    $ans6=$_POST['ans6'];
    $ans7=$_POST['ans7'];
    $ans8=$_POST['ans8'];
    $ans9=$_POST['ans9'];

    $sql= "INSERT INTO survey (customer,ans1,ans2,ans3,ans4,ans5,ans6,ans7,ans8,ans9)
                      VALUES ('$Username','$ans1','$ans2','$ans3','$ans4','$ans5','$ans6','$ans7','$ans8','$ans9')";

    $query = $conn->query($sql);
    echo '<script>alert("Thank you for filling the survey!")</script>';
    header("Location:../Homepage/HomePagePHP.php");
    
}
 ?>
