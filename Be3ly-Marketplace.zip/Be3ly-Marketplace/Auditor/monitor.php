<?php include "auditorDashboard.php"?>

<?php


?>
<html>
<head>

<link rel="stylesheet" href="../CSS/messages.css">

 <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
   <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/css/bootstrap.min.css">
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/js/bootstrap.min.js"></script>
<style>


.content {
  max-width: 500px;
  margin: auto;
  background: white;
  padding: 10px;
}
</style>
</head>
<title>Monitor Admins</title>
<body>
  <h1 style="text-align:center; color:#033955;">Admins communication with the customers</h1>
  <script>
  function func(){
  	alert("Investigation request is sent successfully");

  }
  </script>
  <?php

//---------------------Inserting Comment in Database---------------------//

  if (isset($_POST['text'])) {
      $comment = $_POST["text"];
      $user = $_POST["user"];

      $query = "INSERT INTO auditorcomments  VALUES(NULL,".$_SESSION['id'].", $user,'$comment')";

      if(!$conn->query($query)){
          echo $conn->error;
      }
}
//---------------------Sending Invitigation Request to HR (inserting in db)---------------------//

  if (isset($_POST['request'])) {
      $statement = $_POST["request"];
      $user = $_POST["user"];
      $query = "INSERT INTO investigationrequest VALUES(NULL,".$_SESSION['id'].",$user,'$statement')";

      if(!$conn->query($query)){
          echo $conn->error;
      }

}
  ?>
<div class="col-sm-3">
               <!-- searching form -->
      <form method="GET">
  	    <input type="text" name="search" placeholder="Type the admins's name">&nbsp;<button type="submit" class="btn">Search admins</button><br><br>

      </form>


	  <?php


          $users_query = "SELECT * FROM user WHERE UserType=1";
          if (isset($_GET['search'])) {
              $users_query = "SELECT * FROM user WHERE Name LIKE '%" . $_GET['search'] . "%' AND UserType=1" ;

          }
          $users = $conn->query($users_query);
      ?>

          <?php
          if ($users->num_rows == 0) {
              echo "<h2>No admins found</h2>";
              echo "<button style='background-color:#212f45; color:white;padding:5px 5px 5px 5px;'class='glyphicon glyphicon-arrow-left' title='Go Back' onclick='history.back()'></button>";

          }
  		else{
  		echo"choose from the admins:";
  		echo"<br>";
  		}
          while ($row = $users->fetch_assoc()) {

          ?>

              <a href="?u=<?php echo $row['id']; ?>"><img width="50px" src="https://i.pinimg.com/originals/51/f6/fb/51f6fb256629fc755b8870c801092942.png"><b><?php echo $row['Name']; ?></b></a><br>

      <?php
          }


      ?>
	  </div>
	  <!-- getting the messages history of the requested admin -->
	  <div class="content">
      <?php
      if (isset($_GET['u'])) {



  		$query = "SELECT * FROM user WHERE id=" . $_GET['u'];
          if ($name = $conn->query($query))
              while ($row = $name->fetch_assoc()) {
  				echo "<h3 style='color:#033955;'>". $row['Name'] ."'s conversations</h3>";
  			}


          $messages_query = "SELECT * FROM messages WHERE ( receiver=" . $_GET['u'] . ") OR ( sender=" . $_GET['u'] . ") ORDER BY id ASC";
          if ($messages = $conn->query($messages_query))
              while ($row = $messages->fetch_assoc()) {
                  $user_query = "SELECT * FROM user WHERE id=" . $row['sender'];
                  $user_info = $conn->query($user_query);
                  $user_data = $user_info->fetch_assoc();
      ?>

  	<br>
              <img src="https://i.pinimg.com/originals/51/f6/fb/51f6fb256629fc755b8870c801092942.png" width="40px"><b><?php echo $user_data['Name']; ?></b>
              <br>
  			<?php
  			if ($row['messageContent'] !=""){
               echo"<p>". $row['messageContent']. "</p>";
  			 echo"<br>";
  			}
  			else {
             echo "<img src='images/".$row['image']."' width='400' height='200' >";
  			echo "<br>";
                 }
                ?>
              <?php
              }
  			?>


   <?php
   //---------------------Displaying Comments History---------------------//
    $auditor_query = "SELECT * FROM auditorcomments";
   $user=$_GET['u'];
          $auditor = $conn->query($auditor_query);

          if ($auditor->num_rows != 0) {

  			 $auditor_query = "SELECT comment FROM auditorcomments WHERE admin=$user";
  			         $auditor = $conn->query($auditor_query);
  			 while ($row = $auditor->fetch_assoc()) {
  				 echo"Auditor comment::" . $row['comment']."<br>";

          }
  		}
          ?>

  		<br>
          <br>
          <form method="POST">
              <input type="text" name="text" placeholder="type your comment">&nbsp;<button type="submit" class="btn">comment on this admin</button>
              <input type="hidden" name="user" value="<?php echo $_GET['u']?>">
          </form>
  		<form method="POST">
              <input type="text" name="request" placeholder="type your request">
  			<button type="submit"  class="btn"onclick="func();">send investigation request to the HR</button>
              <input type="hidden" name="user" value="<?php echo $_GET['u']?>">
          </form>
		  </div>

      <?php

      }
	  ?>


</body>
</html>
