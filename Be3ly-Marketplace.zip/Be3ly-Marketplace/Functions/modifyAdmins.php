<?php
include '../database-connection.php';

//--------------------CREATE NEW ADMIN--------------------//

if(count($_POST)>0){
	if($_POST['type']==1){
		$name=$_POST['name'];
		$username=$_POST['username'];
		$password=$_POST['password'];
		$email=$_POST['email'];

		$add = "INSERT INTO user (Name, Username, Password, Email, UserType)
		 				VALUES ('$name','$username', '$password', '$email',1)";

		if (mysqli_query($conn, $add)) {
			echo json_encode(array("statusCode"=>200));
		}
		else {
			echo "Error: " . $add . "<br>" . mysqli_error($conn);
		}
		mysqli_close($conn);
	}
}



//--------------------DELETE--------------------//

if(count($_POST)>0){
	if($_POST['type']==3){
		$id=$_POST['id'];
		$delete = "DELETE FROM user WHERE id=$id ";
		if (mysqli_query($conn, $delete)) {
			echo $id;
		}
		else {
			echo "Error: " . $delete . "<br>" . mysqli_error($conn);
		}
		mysqli_close($conn);
	}
}


?>
