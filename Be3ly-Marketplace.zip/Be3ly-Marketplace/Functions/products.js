//---------------------------------SELECT ALL CHECKBOX---------------------------------//

$(document).ready(function(){
  $('[data-toggle="tooltip"]').tooltip();
  var checkbox = $('table tbody input[type="checkbox"]');
  $("#selectAll").click(function(){
    if(this.checked){
      checkbox.each(function(){
        this.checked = true;
      });
    } else{
      checkbox.each(function(){
        this.checked = false;
      });
    }
  });
  checkbox.click(function(){
    if(!this.checked){
      $("#selectAll").prop("checked", false);
    }
  });
});


//---------------------------------PRODUCTS TABLE---------------------------------//

//--------------------ADD PRODUCT--------------------//

$(document).on('click','#btn-add',function(e) {
  var data = $("#product_form").serialize();
  $.ajax({
    data: data,
    type: "post",
    url: "../Functions/modifyProducts.php",
    success: function(dataResult){
        var dataResult = JSON.parse(dataResult);

        // SUCCESSFUL DATA INSERTION
        if(dataResult.statusCode==200){
          $('#addProductModal').modal('hide');
          alert('Data added successfully !');
                      location.reload();
        }
        // UNSUCCESSFUL DATA INSERTION
        else if(dataResult.statusCode==201){
           alert(dataResult);
        }
    }
  });
});

//--------------------EDIT PRODUCT--------------------//


$(document).on('click','.update',function(e) {
  var id=$(this).attr("data-id");
  var name=$(this).attr("data-name");
  var category=$(this).attr("data-category");
  var description=$(this).attr("data-description");
  var price=$(this).attr("data-price");
  var quantity=$(this).attr("data-quantity");
  var image=$(this).attr("data-image");

  $('#id_u').val(id);
  $('#name_u').val(name);
  $('#category_u').val(category);
  $('#description_u').val(description);
  $('#price_u').val(price);
  $('#quantity_u').val(quantity);
  $('#image_u').val(image);
});
// <!-- Update -->
$(document).on('click','#update',function(e) {
  var data = $("#update_form").serialize();
  $.ajax({
    data: data,
    type: "post",
    url: "../Functions/modifyProducts.php",
    success: function(dataResult){
        var dataResult = JSON.parse(dataResult);
        if(dataResult.statusCode==200){
          $('#editProductModal').modal('hide');
          alert('Data updated successfully !');
                      location.reload();
        }
        else if(dataResult.statusCode==201){
           alert(dataResult);
        }
    }
  });
});

//--------------------DELETE PRODUCT--------------------//


$(document).on("click", ".delete", function() {
  var id=$(this).attr("data-id");
  $('#id_d').val(id);

});

$(document).on("click", "#delete", function() {
  $.ajax({
    url: "../Functions/modifyProducts.php",
    type: "POST",
    cache: false,
    data:{
      type:3,
      id: $("#id_d").val()
    },
    success: function(dataResult){
        $('#deleteProductModal').modal('hide');
        $("#"+dataResult).remove();

    }
  });
});
