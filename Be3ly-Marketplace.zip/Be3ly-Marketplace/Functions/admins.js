//---------------------------------SELECT ALL CHECKBOX---------------------------------//

$(document).ready(function(){
  $('[data-toggle="tooltip"]').tooltip();
  var checkbox = $('table tbody input[type="checkbox"]');
  $("#selectAll").click(function(){
    if(this.checked){
      checkbox.each(function(){
        this.checked = true;
      });
    } else{
      checkbox.each(function(){
        this.checked = false;
      });
    }
  });
  checkbox.click(function(){
    if(!this.checked){
      $("#selectAll").prop("checked", false);
    }
  });
});


//---------------------------------ADMINS TABLE---------------------------------//

//----Add Admin----//
$(document).on('click','#btn-add',function(e) {
  var data = $("#admin_form").serialize();
  $.ajax({
    data: data,
    type: "post",
    url: "../Functions/modifyAdmins.php",
    success: function(dataResult){
        var dataResult = JSON.parse(dataResult);

        // SUCCESSFUL DATA INSERTION
        if(dataResult.statusCode==200){
          $('#addAdminModal').modal('hide');
          alert('Data added successfully !');
                      location.reload();
        }
        // UNSUCCESSFUL DATA INSERTION
        else if(dataResult.statusCode==201){
           alert(dataResult);
        }
    }
  });
});

$(document).on("click", ".delete", function() {
  var id=$(this).attr("data-id");
  $('#id_d').val(id);

});
$(document).on("click", "#delete", function() {
  $.ajax({
    url: "../Functions/modifyAdmins.php",
    type: "POST",
    cache: false,
    data:{
      type:3,
      id: $("#id_d").val()
    },
    success: function(dataResult){
        $('#deleteAdminModal').modal('hide');
        $("#"+dataResult).remove();

    }
  });
});
$(document).on("click", "#delete_selected", function() {
  var user = [];
  $(".admin_checkbox:checked").each(function() {
    user.push($(this).data('user-id'));
  });
  if(user.length <=0) {
    alert("Please select records.");
  }
  else {
    WRN_PROFILE_DELETE = "Are you sure you want to delete "+(user.length>1?"these":"this")+" row?";
    var checked = confirm(WRN_PROFILE_DELETE);
    if(checked == true) {
      var selected_values = user.join(",");
      console.log(selected_values);
      $.ajax({
        type: "POST",
        url: "../Functions/modifyAdmins.php",
        cache:false,
        data:{
          type: 4,
          id : selected_values
        },
        success: function(response) {
          var ids = response.split(",");
          for (var i=0; i < ids.length; i++ ) {
            $("#"+ids[i]).remove();
          }
        }
      });
    }
  }
});
