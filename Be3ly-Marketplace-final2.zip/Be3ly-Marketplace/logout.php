<?php
session_start();
session_destroy();

//MARKETPLACE HOMEPAGE
header("location:http://localhost/Be3ly-Marketplace/Homepage/HomepagePHP.php");
 ?>
