<?php include "adminDashboard.php"?>

<html>
<title>Admins</title>

<head>
  <link rel="stylesheet" type="text/css" href="../CSS/tables.css">

  <!-- BOOTSTRAP TABLE -->
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/css/bootstrap.min.css">

  <!-- EDIT/DELETE ICONS -->
  <link rel="stylesheet" href="https://fonts.googleapis.com/icon?family=Material+Icons">

  <!-- AJAX FUNCTIONS FILE -->
  <script src="../Functions/admins.js"></script>


</head>

<body>
<div class="container">


  <a href="JavaScript:void(0);" id="delete_selected" data-toggle="modal"style="margin-left:10px;"title="Delete All Selected Products"class="pull-right hidden-xs showopacity glyphicon glyphicon-trash btn btn-danger"></a>

  <a href="#addAdminModal" data-toggle="modal" title="Add A New Admin"  class="pull-right hidden-xs90 showopacity glyphicon glyphicon-plus btn btn-success" /></a>


  <h2>Manage Admins</h2>
  <table class="table table-hover">
    <thead>
      <tr>
        <th>
            <span class="custom-checkbox">
              <input type="checkbox" id="selectAll">
              <label for="selectAll"></label>
            </span>
        </th>
        <th>ID</th>
        <th>Name</th>
        <th>Username</th>
        <th>Password</th>
        <th>Email</th>
        <th>Action</th>
      </tr>
    </thead>
    <tbody>
    <?php

    $sql ="SELECT * FROM user WHERE UserType=1";
    $result=mysqli_query($conn,$sql);

    while($row=mysqli_fetch_assoc($result)){

      ?>
      <tr id="<?php echo $row["id"]; ?>">
        <td>
          <span class="custom-checkbox">
            <input type="checkbox" class="admin_checkbox" data-user-id="<?php echo $row["id"]; ?>">
            <label for="checkbox2"></label>
          </span>
        </td>
        <!-- DISPLAYING ADMINS -->
        <td><?php echo $row["id"]?></td>
        <td><?php echo $row["Name"]?></td>
        <td><?php echo $row["Username"]?></td>
        <td><?php echo $row["Password"]?></td>
        <td><?php echo $row["Email"]?></td>

      <td>
        <a href="#deleteAdminModal" class="delete" data-id="<?php echo $row["id"]; ?>"data-toggle="modal">
          <i class="material-icons" data-toggle="tooltip" title="Delete">&#xE872;</i>
        </a>

        </td>

      </tr>
      <?php
      }
      ?>
    </tbody>
  </table>
</div>



<!--- MODALS --->

<!-- Add Admin -->

<div id="addAdminModal" class="modal fade">
  <div class="modal-dialog">
    <div class="modal-content">
      <form id="admin_form">
        <div class="modal-header">
          <h4 class="modal-title">Add Admin</h4>
          <button type="button" class="close" data-dismiss="modal" aria-hidden="true">&times;</button>
        </div>
        <div class="modal-body">
          <div class="form-group">
            <label>Name</label>
            <input type="text" id="name" name="name" class="form-control" required>
          </div>
          <div class="form-group">
            <label>Username</label>
            <input type="text" id="username" name="username" class="form-control" required>
          </div>
          <div class="form-group">
            <label>Password</label>
            <input type="password" id="password" name="password" class="form-control" required>
          </div>
          <div class="form-group">
            <label>Email</label>
            <input type="email" id="email" name="email" class="form-control" required>
          </div>

        </div>
        <div class="modal-footer">
            <input type="hidden" value="1" name="type">
          <input type="button" class="btn btn-default" data-dismiss="modal" value="Cancel">
          <button type="button" class="btn btn-success" id="btn-add">Add</button>
        </div>
      </form>
    </div>
  </div>
</div>

<!-- Delete Modal -->

<div id="deleteAdminModal" class="modal fade">
  <div class="modal-dialog">
    <div class="modal-content">
      <form>

        <div class="modal-header">
          <h4 class="modal-title">Delete Admin</h4>
          <button type="button" class="close" data-dismiss="modal" aria-hidden="true">&times;</button>
        </div>
        <div class="modal-body">
          <input type="hidden" id="id_d" name="id" class="form-control">
          <p>Are you sure you want to delete this record?</p>
          <p class="text-warning"><small>This action cannot be undone.</small></p>
        </div>
        <div class="modal-footer">
          <input type="button" class="btn btn-default" data-dismiss="modal" value="Cancel">
          <button type="button" class="btn btn-danger" id="delete">Delete</button>
        </div>
      </form>
    </div>
  </div>
</div>



</body>
</html>
