<?php include "adminDashboard.php"?>

<html>
<title>Customers</title>

<head>
  <!-- BOOTSTRAP TABLE -->
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/css/bootstrap.min.css">

  <!-- EDIT/DELETE ICONS -->
  <link rel="stylesheet" href="https://fonts.googleapis.com/icon?family=Material+Icons">

</head>
<body>

<div class="container">
  <h2>&nbsp;View Customers <span class="pull-left hidden-xs showopacity glyphicon glyphicon-eye-open"></span></h2>
  <table class="table table-hover">
    <thead>
      <tr>
        <th>ID</th>
        <th>Name</th>
        <th>Username</th>
        <th>Password</th>
        <th>Email</th>
      </tr>
    </thead>
    <?php

    $sql ="SELECT * FROM user WHERE UserType=4";
    $result=mysqli_query($conn,$sql);
    if (mysqli_num_rows($result)>0){

      while($row=mysqli_fetch_assoc($result)){

                echo "<td>" . $row['id'] . "</td> &nbsp";
               echo "<td>" . $row['Name'] . "</td> &nbsp";

               echo "<td>" . $row['Username'] . "</td> &nbsp";

               echo "<td>" . $row['Password'] . "</td> &nbsp";

               echo "<td>" . $row['Email'] . "</td> &nbsp";


               echo "</tr>";

      }

    }

     ?>
       </table>

</div>
</body>
</html>
