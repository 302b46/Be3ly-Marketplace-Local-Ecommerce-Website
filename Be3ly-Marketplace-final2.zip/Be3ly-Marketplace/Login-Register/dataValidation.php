<?php

if(!empty($_POST('username')))
{
  $username = filter_var($_POST['username'],FILTER_SANITIZE_EMAIL);

  if(filter_var($username, FILTER_VALIDATE_EMAIL)===false)
  {
    echo "<div class='invalid'> Invalid Username. </div>"
  }
}

if(!empty($_POST('email')))
{
  $email = filter_var($_POST['email'],FILTER_SANITIZE_EMAIL);

  if(!filter_var($email, FILTER_VALIDATE_EMAIL)===false)
  {
    echo "<div class='invalid'> Invalid Email. </div>"
  }
}

if(!empty($_POST('password')))
{
  $password = filter_var($_POST['password'],FILTER_SANITIZE_EMAIL);

  if(filter_var($password, FILTER_VALIDATE_EMAIL)===false)
  {
    echo "<div class='invalid'>Invalid Password. </div>"
  }
}

?>
