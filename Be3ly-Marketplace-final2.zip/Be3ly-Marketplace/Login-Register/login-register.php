<?php
 include "../database-connection.php";

//-------------------------------------------REGISTRATION FORM-------------------------------------------//

//initializing registration variables

$name = "";
$username = "";
$email = "";
$errors = array();

if(isset($_POST['reg_user'])){

//retreiving user input data from form into and putting them into variables

$name = mysqli_real_escape_string($conn , $_POST['name']);
$username = mysqli_real_escape_string($conn , $_POST['username']);
$phoneNumber = mysqli_real_escape_string($conn , $_POST['phonenumber']);
$address = mysqli_real_escape_string($conn , $_POST['address']);
$email = mysqli_real_escape_string($conn , $_POST['email']);
$password_1 = mysqli_real_escape_string($conn , $_POST['password']);
$password_2 = mysqli_real_escape_string($conn , $_POST['conf_password']);


//validating the registration form's data

if (empty($name)) { array_push($errors, "Name is required"); }
if (empty($username)) { array_push($errors, "Username is required"); }
if (empty($email)) { array_push($errors, "Email is required"); }
if (empty($password_1)) { array_push($errors, "Password is required"); }

if ($password_1 != $password_2)
{
	array_push($errors, "The two passwords do not match");
  }

//checking username and email in database to make sure they do not already exist

$check_user = "SELECT * FROM user WHERE Username='$username' OR  Email='$email' LIMIT 1 ";
$result = mysqli_query($conn, $check_user);
$user = mysqli_fetch_assoc($result);

//checking if user and/or email exist

if($user)
{
  if($user['Username']===$username)
  {
    array_push($errors, "Username already exists, please choose another one.");
  }

  if($user['Email']===$email)
  {
    array_push($errors, "Email already exists, please use another one.");
  }
}

//registering the user into database if there are no errors
if(count($errors)==0)
{
  //registration query

  $register = "INSERT INTO user VALUES ('$name','$username', '$password', '$email','$phoneNumber','$address', NULL,4)";
  mysqli_query($conn, $register);
  $_SESSION['Username'] = $username;
  $_SESSION['success'] = "Logging In Successful!";
  header('location:homepage.php');
}

}

//-------------------------------------------LOGIN FORM-------------------------------------------//

if(isset($_POST['login_user'])) {

  $username = mysqli_real_escape_string($conn, $_POST['username']);
  $password = mysqli_real_escape_string($conn, $_POST['password']);

  if(empty($username)){ array_push($errors, "Username is required");}

  if(empty($password)){ array_push($errors, "Password is required");}

  if(count($errors) == 0) {

  	$login = "SELECT * FROM user WHERE Username='$username' AND Password='$password'";
  	$results = mysqli_query($conn, $login);


  	if(mysqli_num_rows($results) == 1) {

			$user = mysqli_fetch_assoc($results);

  	  $_SESSION['Username'] = $username;
      $_SESSION['success'] = "Logging In Successful!";
      $_SESSION['id'] =$user['id'];

			//directing user to a homepage based on their user type (admin, auditor, hr, or customer)

			//Admin Homepage
			if($user['UserType']=='1')
				{
					$_SESSION['Username'] = $username;
					header('location: ../Admin/adminHomepage.php');
					exit;
				}

			//Auditor Homepage
			else if($user['UserType']=='2')
			{
				$_SESSION['Username'] = $username;
				header('location: ../Auditor/auditorHomepage.php');
			}

			//HR Homepage
			else if($user['UserType']=='3')
			{
				$_SESSION['Username'] = $username;
				header('location: ../HR/hrHomepage.php');
			}

			//Customer Homepage
			else if($user['UserType']=='4')
  	  {
				$_SESSION['Username'] = $username;
				header('location: ../Homepage/HomePagePHP.php');
  		}

		else {
  		array_push($errors, "Incorrect Username and/or password.");

  	}

}
}
}

?>
