<?php include "login-register.php" ?>
<html>
<head>

  <link rel="stylesheet" type="text/css" href="../CSS/login-register.css">
  <style>
    .invalid{color: #D31212;}
  </style>
  <script src="https://code.jquery.com/jquery-3.5.1.min.js" type="text/javascript"> </script>

  <!-- DATA VALIDATION -->
  <script>
    function validateUsername()
    {
      jQuery.ajax(
      {
        url: "dataValidation.php",
        data: 'username'+$("#username").val(),
        type: "POST",
        success: function(data)
        {
          $("$msg").html(data);
        }
      });
    }

    function validateEmail()
    {
      Query.ajax(
      {
        url: "dataValidation.php",
        data: 'email'+$("#email").val(),
        type: "POST",
        success: function(data)
        {
          $("$msg").html(data);
        }
      });
    }
    function validatePassword()
    {
      Query.ajax(
      {
        url: "dataValidation.php",
        data: 'password'+$("#password").val(),
        type: "POST",
        success: function(data)
        {
          $("$msg").html(data);
        }
      });
    }
  </script>

</head>
<body>
  <!-- <img src="logo.png" style="padding-left: 20px;
  padding-top: 20px;
  width: 120px;
  height: 50px;" /> -->
  <div class="header">
  	<h2>Create A New Account</h2>
  </div>

  <form method="post" action="registration.php">
  	<?php include('errors.php'); ?>

    <div class="input-group">
  	  <label>Full Name</label>
  	  <input type="text" name="name">
  	</div>

  	<div class="input-group">
  	  <label>Username</label>
  	  <input type="text" name="username" id="username" onkeyup="validateUsername()">
  	</div>
    <div id="msg"></div>
  	<div class="input-group">
  	  <label>Email</label>
  	  <input type="email" name="email" id="email" onkeyup="validateEmail()">
  	</div>
    <div class="input-group">
  	  <label>Phone Number</label>
  	  <input type="text" name="phonenumber" id="phonenumber" onkeyup="validateUsername()">
  	</div>
    <div class="input-group">
  	  <label>Address</label>
  	  <input type="text" name="address" id="address" onkeyup="validateUsername()">
  	</div>
    <div id="msg"></div>
  	<div class="input-group">
  	  <label>Password</label>
  	  <input type="password" name="password" id="password" onkeyup="validatePassword()">
  	</div>
  	<div class="input-group">
  	  <label>Confirm password</label>
  	  <input type="password" name="conf_password">
  	</div>
    <br />



  	<div class="input-group">
  	  <button type="submit" class="btn" name="reg_user">Sign Up</button><br />
  	</div>
<br /><hr /><br />
  	<p style="text-align: center;">
  		Already a member? <a href="login.php">Sign in</a>
  	</p>
  </form>
</body>
</html>
