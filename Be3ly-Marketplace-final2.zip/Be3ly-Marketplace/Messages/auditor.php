<html>
<head>
<title>Auditor</title>
</head>
<body>
<h1 style="text-align:center; color:#033955;">Auditor</h1>
<a href="viewCommunication.php">view communication</a><br>
<a href="sendSurveys.php">send surveys</a><br>



</body>
</html>
