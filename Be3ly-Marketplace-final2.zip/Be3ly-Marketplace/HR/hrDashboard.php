<?php include "../database-connection.php"?>
<?php include "sessions.php"?>

<html>
<head>
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/css/bootstrap.min.css">
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/js/bootstrap.min.js"></script>

</head>
<body>
  <nav class="navbar navbar-inverse" style="background:#212f45; padding:20px;border-radius:0px; font-size:20px;">
    <div class="container-fluid">
      <div class="navbar-header">
        <!-- link will be the marketplace homepage -->
        <a style="padding-left:2px;padding-right:50px;font-size:25px;"class="navbar-brand" href="#">Be3ly Marketplace</a>
      </div>
      <ul class="nav navbar-nav">
        <li><a href="hrHomepage.php">Home <span class="pull-right hidden-xs showopacity glyphicon glyphicon-home"></span></a></li>
        <li><a href="profile.php">Profile <span class="pull-right hidden-xs showopacity glyphicon glyphicon-user"></span></a></li>
        <li><a href="adminPenalties.php">Penalties <span class="pull-right hidden-xs showopacity glyphicon glyphicon-remove-sign"></span></a></li>
        <li><a href="investigationRequests.php">Invesigation Requests<span class="pull-right hidden-xs showopacity 	glyphicon glyphicon-question-sign"></span></a></li>
      </ul>
      <ul class="nav navbar-nav navbar-right">
        <li>
          <a>Hello, <?php echo $row['Name'];?></a>
        </li>
        <li><a href="../logout.php"><span class="glyphicon glyphicon-log-out"></span> Logout</a></li>
      </ul>
    </div>
  </nav>



</body>
</html>
