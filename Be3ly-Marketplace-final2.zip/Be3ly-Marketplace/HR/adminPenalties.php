<?php include "hrDashboard.php"?>
<html>
<head>
  <link rel="stylesheet" type="text/css" href="../CSS/tables.css">

  <!-- BOOTSTRAP TABLE -->
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/css/bootstrap.min.css">

</head>
<title>Admins</title>
<body>

<div class="container">
  <button type="button" style="border-radius:10px;margin-left:980px;" class="btn btn-primary" onclick="document.location='viewPenalties.php'">View Admins With A Penalty</button>

  <h2>Admins</h2>

  <table class="table table-hover">
    <thead>
      <tr>
        <th>ID</th>
        <th>Name</th>
        <th>Username</th>
        <th>Password</th>
        <th>Email</th>
        <th>Action</th>
      </tr>
    </thead>
    <tbody>
    <?php

    $sql ="SELECT * FROM user WHERE UserType=1";
    $result=mysqli_query($conn,$sql);

    while($row=mysqli_fetch_assoc($result)){

      ?>
      <tr id="<?php echo $row["id"]; ?>">

        <!-- DISPLAYING ADMINS -->
        <td><?php echo $row["id"]?></td>
        <td><?php echo $row["Name"]?></td>
        <td><?php echo $row["Username"]?></td>
        <td><?php echo $row["Password"]?></td>
        <td><?php echo $row["Email"]?></td>

        <td>
          <button type="button" style="border-radius:10px;" class="btn btn-danger" onclick="document.location='managePenalties.php'">Add Penalty</button>
        </td>


      </tr>
      <?php
      }
      ?>
    </tbody>
  </table>
</div>


</body>
</html>
