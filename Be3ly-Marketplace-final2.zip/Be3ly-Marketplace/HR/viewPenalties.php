<?php include "hrDashboard.php"?>
<html>
<title>View Penalties</title>
<body>
  <div class="container">
    <button style="border-radius:10px;margin-left:980px;"class=" btn btn-primary glyphicon glyphicon-arrow-left" title="Go Back" onclick="history.back()"></button>
    <h2>Penalties</h2>

    <table class="table table-hover">
      <thead>
        <tr>
          <th>ID</th>
          <th>Admin</th>
          <th>Number of Penalties</th>
          <th>Action</th>
        </tr>
      </thead>
      <tbody>

<?php

  $penalty_query="SELECT * FROM penalty";
  $penalty=mysqli_query($conn,$penalty_query);
  while($row=mysqli_fetch_assoc($penalty))
  {
  ?>
    <tr id="<?php echo $row["id"]; ?>">
      <td><?php echo $row["id"]?></td>
      <td><?php echo $row["admin"]?></td>
      <td><?php echo $row["amount"]?></td>
      <td>
        <button type="button" style="border-radius:10px;" class="btn btn-danger" onclick="managePenalties.php">Delete Penalty</button>
      </td>
  </tr>
    <?php
  }
?>
</div>
</tbody>
</table>
</body>
</html>
