<?php include "auditorDashboard.php"?>
<html>
<title>Customers</title>

<head>
  <!-- BOOTSTRAP TABLE -->
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/css/bootstrap.min.css">


</head>
<body>

<div class="container">
  <h2>&nbsp; Customers</h2>
  <table class="table table-hover">
    <thead>
      <tr>
        <th>ID</th>
        <th>Name</th>
        <th>Username</th>
        <th>Email</th>
        <th>Action</th>
      </tr>
    </thead>
    <?php

    $sql ="SELECT * FROM user WHERE UserType=4";
    $result=mysqli_query($conn,$sql);
    if (mysqli_num_rows($result)>0){

      while($row=mysqli_fetch_assoc($result)){

                echo "<td>" . $row['id'] . "</td> &nbsp";
               echo "<td>" . $row['Name'] . "</td> &nbsp";

               echo "<td>" . $row['Username'] . "</td> &nbsp";


               echo "<td>" . $row['Email'] . "</td> &nbsp";

               echo "<td><button type='button'style='border-radius:10px;' class='btn btn-dark'>Send Survey</button> </td>";


               echo "</tr>";

      }

    }

     ?>
       </table>

       <button type="button"style="background-color: #293a6a;border-radius:10px; flex:right;" class="btn btn-info" onclick="document.location='survey.php'">View Survey</button>

</div>
</body>
</html>
