<?php include "../database-connection.php"?>

<?php
if(isset($_POST['submitSurvey']))
{
  // $customer = $_POST['customer'];


//--------------------COMMUNICATION SURVEY--------------------//


    $ans7=$_POST['ans7'];
    $ans8=$_POST['ans8'];
    $ans9=$_POST['ans9'];


    $communication = "INSERT INTO survey (customer, surveyType,ans1,ans2,ans3)
                      VALUES ('nerminesalah','Communication',$ans7,$ans8,$ans9)";

//     if(!$conn->query($communication))
//     {
//       echo $conn->error;
//     }
//
//
//
//
// //--------------------PRODUCTS SURVEY--------------------//
//
//
//     $surveyType="Product";
//     $ans4=$_POST['ans4'];
//     $ans5=$_POST['ans5'];
//     $ans6=$_POST['ans6'];
//
//
//     $product = "INSERT INTO survey (customer, surveyType,ans1,ans2,ans3)
//                       VALUES ('nerminesalah','Product',$ans4,$ans5,$ans6)";
//
//
//   //--------------------WEBSITE SURVEY--------------------//
//
//
//     $surveyType="Website";
//     $ans1=$_POST['ans1'];
//     $ans2=$_POST['ans2'];
//     $ans3=$_POST['ans3'];
//
//
//     $website = "INSERT INTO survey (customer, surveyType,ans1,ans2,ans3)
//                       VALUES ('nerminesalah','Website',$ans1,$ans2,$ans3)";

}

 ?>
