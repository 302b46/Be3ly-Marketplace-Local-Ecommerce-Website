<?php
include "update.php";
include "../header.php";

?>
<!DOCTYPE html>
<html lang="en" dir="ltr">
  <head>
    <meta charset="utf-8">
    <title>View Photo</title>
    <link href="maxcdn.bootstrapcdn.com/bootstrap/4.1.1/css/bootstrap.min.css" rel="stylesheet" id="bootstrap-css">
    <script src="maxcdn.bootstrapcdn.com/bootstrap/4.1.1/js/bootstrap.min.js"></script>
    <script src="cdnjs.cloudflare.com/ajax/libs/jquery/3.2.1/jquery.min.js"></script>
    <script src="js/CustomerPhoto.js"></script>
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>
    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>

    <title>Customer Profile</title>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">

  </head>
  <div class="container bootstrap snippet">
      <div class="row"> <!--Beginning of first container-->
    		<div class="col-sm-10"><h1><?php
            $Username=$_SESSION['Username'];
            echo "Welcome ".$Username;
         ?></h1></div>


      	<div class="col-sm-2"><a href="/users" class="pull-right"></a></div>
      </div>
      <div class="row">
    		<div class="col-sm-3"><!--left col-->

        <div class="text-center">

          <!--Displaying profile picture from the database-->
          <?php
            $sql="SELECT ProfilePicture FROM user WHERE Username='$Username'";
            $res = mysqli_query($conn,$sql);

            if (mysqli_num_rows($res)>0) {
              while ($images=mysqli_fetch_assoc($res)){  ?>
                <div class="alb">
              <img src="img/<?=$images['ProfilePicture']?>" style="width:200px;border-radius: 200%;height:200px; border-color: #242484;">
             </div>
             <?php  }  }?>
          <br>
          <?php if(isset($_GET['error'])): ?>
            <p><?php echo $_GET['error']; ?></p>
          <?php endif ?>
              <form class="" action="upload.php" method="post" enctype="multipart/form-data">
                <h5>Upload a new photo?</h5>
                <input type="file" name="image" value="">
                <input type="submit" name="submit" value="Upload">
                <input type="hidden" name="username" value="<?php echo $Username ?>">
              </form>




        </div><br> <!--End of first container-->

          </div><!--/col-3-->

          <!--Navigation Tabs-->
      	<div class="col-sm-9">
              <ul class="nav nav-tabs">
                  <li class="active" ><a data-toggle="tab" href="#profile"  style="color:#242484;">Edit Profile</a></li>
                  <li><a data-toggle="tab" href="#messages" style="color:#242484;">Message History</a></li>
                  <li><a data-toggle="tab" href="#orders" style="color:#242484;">Order History</a></li>
                </ul>

              <!--Beginning of profile tab contents-->
              <div class="tab-pane active" id="profile">

                    <form class="form" action="" method="post">
                        <div class="form-group">
                          <div class="col-xs-6">
                            <label for="name"><h4>Name</h4></label>
                            <?php
                              $sql = "SELECT * FROM user WHERE Username='$Username'";
                              $query = $conn->query($sql);
                          	  $total=mysqli_num_rows($query);
                              $row=$query->fetch_assoc();
                             ?>
                             <input type="text" class="form-control" name="name" value="<?php echo $row['Name'] ?>">
                            </div>
                        </div>
                        <div class="form-group">

                            <div class="col-xs-6">
                              <label for="username"><h4>Username</h4></label>


                              <input type="text" class="form-control" name="username" value="<?php echo $Username ?>" readonly>

                            </div>
                        </div>

                        <div class="form-group">
                            <div class="col-xs-6">
                                <label for="phone"><h4>Phone Number</h4></label>
                                <input type="text" class="form-control" name="phone" value="<?php echo $row['PhoneNumber'] ?>">
                            </div>
                        </div>

                        <div class="form-group">
                            <div class="col-xs-6">
                                <label for="email"><h4>Email</h4></label>
                                <input type="text" class="form-control" name="email" value="<?php echo $row['Email'] ?>" readonly>
                            </div>
                        </div>
                        <div class="form-group">

                            <div class="col-xs-6">
                                <label for="email"><h4>Address</h4></label>
                                <input type="text" class="form-control" name="address" value="<?php echo $row['Address'] ?>">
                            </div>
                        </div>
                        <div class="form-group">
                            <div class="col-xs-6">
                                <label for="password"><h4>Password</h4></label>
                                <input type="password" class="form-control" name="password" value="<?php echo $row['Password'] ?>">
                            </div>
                        </div>
                        <div class="form-group">
                            <div class="col-xs-6">
                              <label for="password2"><h4>Verify new password</h4></label>
                                <input type="password" class="form-control" name="password2" id="password2" placeholder="Confirm Password">
                            </div>
                        </div>

                        <div class="form-group">
                             <div class="col-xs-12">
                                  <br>
                                	<button class="btn btn-lg btn-success pull-right" name="save" type="submit" style="background-color:#d12626;border-color:#242484;"><i class="glyphicon glyphicon-ok-sign"></i> Save</button>
                                  <br>
                                  <br>
                                  <hr>
                              </div>
                        </div>
                	</form>

                <hr>
             <!--End of profile tab contents-->
               </div><!--/tab-pane-->
               <div class="tab-pane" id="messages">

                 <h2></h2>




               </div><!--/tab-pane-->
               <div class="tab-pane" id="orders">




                </div>

                </div><!--/tab-pane-->
            </div><!--/tab-content-->

          </div><!--/col-9-->
      </div><!--/row-->


  <body>



  </body>
</html>
<?php
include "../footer.php";
 ?>
