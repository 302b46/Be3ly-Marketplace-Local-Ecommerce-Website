<?php

$conn = mysqli_connect('localhost', 'root', '', 'be3ly');

if (isset($_POST['save'])) {
  $name=$_POST['name'];
  $username = $_POST['username'];
  $address=$_POST['address'];
  $phone=$_POST['phone'];
  $password_1 = $_POST['password'];
  $password_2 = $_POST['password2'];

  $sql="UPDATE user SET Name='$name',Address='$address',PhoneNumber='$phone' WHERE Username='$username'";
  if ($password_1==$password_2)
  {
    $pass="UPDATE user SET Password='$password_1' WHERE Username='$username'";
    $query = mysqli_query($conn,$pass);
  }
 //  else if ($password_1!=$password_2){
 //    header("refresh:1; url=profile.php");
 //    echo "Passwords do not match";
 //    echo "<br>";
 // }

  $query2 = mysqli_query($conn,$sql);
  if($query2 || $password_1==$password_2){

      header("refresh:1; url=profile.php");
      echo "Record updated successfully";

  }
    else {
      header("refresh:1; url=profile.php");
      echo "Update Failed";
    }
}


?>
