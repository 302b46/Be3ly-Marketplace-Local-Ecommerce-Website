<?php
include '../database-connection.php';

//--------------------CREATE NEW PRODUCT--------------------//

if(count($_POST)>0){
	if($_POST['type']==1){
		$name=$_POST['name'];
		$category=$_POST['category'];
		$description=$_POST['description'];
		$price=$_POST['price'];
    $quantity=$_POST['quantity'];
    $image=$_POST['image'];

		$add = "INSERT INTO product (name, category, description, price, quantity, image)
		 				VALUES ('$name','$category', '$description', '$price','$quantity','$image')";

		if (mysqli_query($conn, $add)) {
			echo json_encode(array("statusCode"=>200));
		}
		else {
			echo "Error: " . $add . "<br>" . mysqli_error($conn);
		}
		mysqli_close($conn);
	}
}


//--------------------EDIT PRODUCT--------------------//

if(count($_POST)>0){
	if($_POST['type']==2){
		$id=$_POST['id'];
		$name=$_POST['name'];
		$category=$_POST['category'];
		$description=$_POST['description'];
		$price=$_POST['price'];
		$quantity=$_POST['quantity'];
		$image=$_POST['image'];

		$edit = "UPDATE product SET name='$name', category='$category', description='$description',
		 					price='$price', quantity='$quantity', image='$image' WHERE id=$id";

		if (mysqli_query($conn, $edit)) {
			echo json_encode(array("statusCode"=>200));
		}
		else {
			echo "Error: " . $edit . "<br>" . mysqli_error($conn);
		}
		mysqli_close($conn);
	}
}

//--------------------DELETE PRODUCT--------------------//

// deleting the record
if(count($_POST)>0){
	if($_POST['type']==3){
		$id=$_POST['id'];
		$sql = "DELETE FROM product WHERE id=$id ";
		if (mysqli_query($conn, $sql)) {
			echo $id;
		}
		else {
			echo "Error: " . $sql . "<br>" . mysqli_error($conn);
		}
		mysqli_close($conn);
	}
}

//deleting selected records
if(count($_POST)>0){
	if($_POST['type']==4){
		$id=$_POST['id'];
		$sql = "DELETE FROM product WHERE id in ($id)";
		if (mysqli_query($conn, $sql)) {
			echo $id;
		}
		else {
			echo "Error: " . $sql . "<br>" . mysqli_error($conn);
		}
		mysqli_close($conn);
	}
}

?>
