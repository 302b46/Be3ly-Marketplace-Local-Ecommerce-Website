<!DOCTYPE html>
<?php
include "../header.php";
?>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Be3ly</title>
    <link href="logoFavion.png" type="image/png" rel="shortcut icon">

<!--Boostrap CDN-->
<link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@4.5.3/dist/css/bootstrap.min.css" integrity="sha384-TX8t27EcRE3e/ihU7zmQxVncDAy5uIKz4rEkgIXeMed4M0jlfIDPvg6uqKI2xXr2" crossorigin="anonymous">
<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/css/bootstrap.min.css">

<!--Font Awesome CDN-->
<script src="https://kit.fontawesome.com/ba83dadc75.js" crossorigin="anonymous">
</script>

<!--Slick Slider-->
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/slick-carousel/1.9.0/slick.min.css" integrity="sha512-yHknP1/AwR+yx26cB1y0cjvQUMvEa2PFzt1c9LlS4pRQ5NOTZFWbhBig+X9G9eYW/8m0/4OXNx8pxJ6z57x0dw==" crossorigin="anonymous" />
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/slick-carousel/1.9.0/slick-theme.min.css" integrity="sha512-17EgCFERpgZKcm0j0fEq1YCJuyAWdz9KUtv1EjVuaOz8pDnh/0nZxmU6BBXwaaxqoi9PQXnRWqlcDB027hgv9A==" crossorigin="anonymous" />

<!--Custom Stylesheet-->
<!--<link rel="stylesheet" href="stylephp.css"> -->
<link rel="stylesheet" href="stylephp.css?v=<?php echo time(); ?>">   <!-- da ely 5ala ye2ra el ta3dilat mn el css file beta3y -->

<!--search bar -->
<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>

<!-- Show Products  -->
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/material-design-iconic-font/2.2.0/css/material-design-iconic-font.min.css">


</head>
<body>

<!-- reading products from database adminproducts -->


<!--Main Section-->
<main>
<!--Slider 1-->
<div class="container" >

  <div id="myCarousel" class="carousel slide" data-ride="carousel">
    <!-- Indicators -->
    <ol class="carousel-indicators">
      <li data-target="#myCarousel" data-slide-to="0" class="active"></li>
      <li data-target="#myCarousel" data-slide-to="1"></li>
      <li data-target="#myCarousel" data-slide-to="2"></li>
      <li data-target="#myCarousel" data-slide-to="3"></li>
      <li data-target="#myCarousel" data-slide-to="4"></li>
      <li data-target="#myCarousel" data-slide-to="5"></li>
      <li data-target="#myCarousel" data-slide-to="6"></li>
    </ol>

    <!-- Wrapper for slides -->
    <div class="carousel-inner">
      <div class="item active">
       <a href="mobiles.php"> <img src="img/1img.jpg" alt="1st Pic" style="width:100%;"> </a>
      </div>

      <div class="item">
       <a href="electronics.php"> <img src="img/2img.jpg" alt="2nd Pic"  style="width:100%;"> </a>
      </div>

      <div class="item">
       <a href="toys.php"> <img src="img/toys.jpg" alt="3rd Pic" style="width:100%;">  </a> <!-- fashion page -->
      </div>

      <div class="item">
       <a href="supermarket.php"> <img src="img/supermarket.jpg" alt="3rd Pic" style="width:100%;">  </a> <!-- supermarket page -->
      </div>

      <div class="item">
      <a href="fashion.php">  <img src="img/fashion.png" alt="3rd Pic" style="width:100%;"> </a>  <!-- fashion page -->
      </div>

      <div class="item">
      <a href="appliances.php">  <img src="img/appliances.jpg" alt="3rd Pic" style="width:100%;"> </a>  <!-- fashion page -->
      </div>

      <div class="item">
      <a href="sports.php">  <img src="img/sport.jpg" alt="3rd Pic" style="width:100%;"> </a>  <!-- fashion page -->
      </div>

    </div>

    <!-- Arrows -->
    <a class="left carousel-control" href="#myCarousel" data-slide="prev">
      <span class="glyphicon glyphicon-chevron-left"></span>
      <span class="sr-only">Previous</span>
    </a>
    <a class="right carousel-control" href="#myCarousel" data-slide="next">
      <span class="glyphicon glyphicon-chevron-right"></span>
      <span class="sr-only">Next</span>
    </a>
  </div>
</div>

<br> <br>

<div class="container">
  <div class="row">
    <div class="col-sm">
       <a href="fashion.php"><img src="img/fashion-poster.jpg" ></a>
    </div>
    <div class="col-sm">
    <a href="electronics.php"><img src="img/electronicsoffers.jpg" ></a>
    </div>
  </div>
</div>
<br>
<div class="container">
    <div class="row clearfix">
        <div class="col">
        <a href="mobiles.php"><img src="img/POSTER1MOBILES.jpg" ></a>

            </div>
        </div>
<br>

        <div class="col">

            </div>
        </div>

 <br>       <br>
<div class="container"> <br>
<div class="row">
    <div class="col">
      <a href="fashion.php"> <img src="img/fashion.jpg" style="width:80%;"> </a>
        <h4> <b>Best Fashion Trends</b> </h4>
    </div>
    <div class="col">
    <a href="electronics.php"> <img src="img/laptopsoffer.png" style="width:80%;"> </a>  <br>
    <div class="col"> <br>
    <a href="mobiles.php"> <img src="img/POSTER1MOBILES.jpg" style="width:80%;"> </a>
    <h4> <b>Best Electronics offers</b> </h4>
    </div>
  </div>

</div>


</div>

</main>
<br> <br>


  <script src="https://code.jquery.com/jquery-3.5.1.slim.min.js" integrity="sha384-DfXdz2htPH0lsSSs5nCTpuj/zy4C+OGpamoFVy38MVBnE+IbbVYUew+OrCXaRkfj" crossorigin="anonymous"></script>
  <script src="https://cdn.jsdelivr.net/npm/bootstrap@4.5.3/dist/js/bootstrap.bundle.min.js" integrity="sha384-ho+j7jyWK8fNQe+A12Hb8AhRq26LrZ/JpcUGGOn+Y7RsweNrtN/tE3MoK7ZeZDyx" crossorigin="anonymous">
  </script>
  <script src="https://cdnjs.cloudflare.com/ajax/libs/slick-carousel/1.9.0/slick.min.js" integrity="sha512-HGOnQO9+SP1V92SrtZfjqxxtLmVzqZpjFFekvzZVWoiASSQgSr4cw9Kqd2+l8Llp4Gm0G8GIFJ4ddwZilcdb8A==" crossorigin="anonymous"></script>
  <script src="D:college/Semester 5/Web Dev/project/farida's work/Be3ly/js/main.js"></script>
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>

  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/js/bootstrap.min.js"></script>
</body>
</html>
<?php
include "../footer.php";
 ?>
