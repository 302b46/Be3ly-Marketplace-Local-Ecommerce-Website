<?php
include "../header.php";
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Supermarket</title>
    <link href="logoFavion.png" type="image/png" rel="shortcut icon">

<!--Boostrap CDN-->
<link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@4.5.3/dist/css/bootstrap.min.css" integrity="sha384-TX8t27EcRE3e/ihU7zmQxVncDAy5uIKz4rEkgIXeMed4M0jlfIDPvg6uqKI2xXr2" crossorigin="anonymous">
<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/css/bootstrap.min.css">

<!--Font Awesome CDN-->
<script src="https://kit.fontawesome.com/ba83dadc75.js" crossorigin="anonymous">
</script>

<!--Slick Slider-->
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/slick-carousel/1.9.0/slick.min.css" integrity="sha512-yHknP1/AwR+yx26cB1y0cjvQUMvEa2PFzt1c9LlS4pRQ5NOTZFWbhBig+X9G9eYW/8m0/4OXNx8pxJ6z57x0dw==" crossorigin="anonymous" />
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/slick-carousel/1.9.0/slick-theme.min.css" integrity="sha512-17EgCFERpgZKcm0j0fEq1YCJuyAWdz9KUtv1EjVuaOz8pDnh/0nZxmU6BBXwaaxqoi9PQXnRWqlcDB027hgv9A==" crossorigin="anonymous" />

<!--Custom Stylesheet-->
<link rel="stylesheet" href="stylephp.css">

<!-- Show Products  -->
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/material-design-iconic-font/2.2.0/css/material-design-iconic-font.min.css">

</head>
<body>

<!-- reading products from database adminproducts -->
<?php


$sql = "SELECT * FROM product WHERE category=6";
$result = $conn->query($sql);


$tt=$result->num_rows;
//echo $tt; echo "<br>";

$idofproduct= array();
$nameofproduct= array();
$pictureofproduct=array();
$priceofproduct=array();
$descriptionofproduct=array();
$categoryofproduct=array();
$r=0;

if ($result->num_rows > 0) {
    while($row = $result->fetch_assoc()) {
    $idofproduct[$r]=$row["id"];
    $nameofproduct[$r]=$row["name"];
    $pictureofproduct[$r]=$row["image"];
    $priceofproduct[$r]=$row["price"];
    $descriptionofproduct[$r]=$row["description"];
    $categoryofproduct[$r]=$row["category"];
    $r++;
    }
}
else {
    echo "0 results";
  }

  $conn->close();
//echo $r;

?>

<main>

<?php
//read product chosen
//el mafrod el products tkon btetmely row row msh kolo f column wahed
$number=$r;

$g=$idofproduct;
//echo $g[0]; echo "<br>";


//echo $categoryofproduct[0];

for($i=0;$i<$number;$i++){
    if($i%4==0){

?>

<div class="container">
    <div class="row clearfix">
        <div class="col">
            <div class="card product_item">
                <div class="body">
                    <div class="cp_img">
                        <img src="data:image/jpeg;base64,<?php  echo base64_encode($pictureofproduct[$i]); ?>" alt="Product" class="img-fluid">
                        <div class="product_details">

                        <h4><a href="ProductIndex.php?category=6&id=<?php echo $i; ?>"> <b>&nbsp;  <?php  echo $nameofproduct[$i] ?> </b>  </a></h4>
                        <ul class="product_price list-unstyled">
                       <li > <b> &nbsp; <?php echo $priceofproduct[$i]; echo "&nbsp;EGP"; ?> </b> </li>
                        </ul>
                    </div>
                        <div class="hover"> &nbsp;
                          <a href="ProductIndex.php?category=6&id=<?php echo $i; ?>" class="btn btn-primary btn-sm waves-effect"><i class="zmdi zmdi-eye" ></i></a>  <!-- view product -->
                           <a href="#" class="btn btn-primary btn-sm waves-effect"><i class="zmdi zmdi-shopping-cart"></i></a>  <!-- add to cart -->
                        </div> <br>
                    </div>
                </div>
            </div>
        </div>

<?php }  else { ?>

        <div class="col">
            <div class="card product_item">
                <div class="body">
                    <div class="cp_img">
                        <img src="data:image/jpeg;base64,<?php echo base64_encode($pictureofproduct[$i]); ?>" alt="Product" class="img-fluid">
                        <div class="product_details">

                        <h4><a href="ProductIndex.php?category=6&id=<?php echo $i; ?>"> <b>&nbsp;  <?php  echo $nameofproduct[$i] ?> </b>  </a></h4>
                        <ul class="product_price list-unstyled">
                       <li > <b> &nbsp; <?php echo $priceofproduct[$i];echo "&nbsp;EGP"; ?> </b> </li>
                        </ul>
                    </div>


                        <div class="hover">   &nbsp;
                            <a href="ProductIndex.php?category=6&id=<?php echo $i ?>" class="btn btn-primary btn-sm waves-effect"><i class="zmdi zmdi-eye"></i></a>   <!-- view product -->
                            <a href="#" class="btn btn-primary btn-sm waves-effect"><i class="zmdi zmdi-shopping-cart"></i></a>  <!-- add to cart -->
                        </div> <br>
                    </div>

                </div>
            </div>
        </div>

        <?php } } ?>



</main>
<br> <br>

  <script src="https://code.jquery.com/jquery-3.5.1.slim.min.js" integrity="sha384-DfXdz2htPH0lsSSs5nCTpuj/zy4C+OGpamoFVy38MVBnE+IbbVYUew+OrCXaRkfj" crossorigin="anonymous"></script>
  <script src="https://cdn.jsdelivr.net/npm/bootstrap@4.5.3/dist/js/bootstrap.bundle.min.js" integrity="sha384-ho+j7jyWK8fNQe+A12Hb8AhRq26LrZ/JpcUGGOn+Y7RsweNrtN/tE3MoK7ZeZDyx" crossorigin="anonymous">
  </script>
  <script src="https://cdnjs.cloudflare.com/ajax/libs/slick-carousel/1.9.0/slick.min.js" integrity="sha512-HGOnQO9+SP1V92SrtZfjqxxtLmVzqZpjFFekvzZVWoiASSQgSr4cw9Kqd2+l8Llp4Gm0G8GIFJ4ddwZilcdb8A==" crossorigin="anonymous"></script>
  <script src="D:college/Semester 5/Web Dev/project/farida's work/Be3ly/js/main.js"></script>
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>

  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/js/bootstrap.min.js"></script>
</body>
</html>
<?php
include "../footer.php";
 ?>
