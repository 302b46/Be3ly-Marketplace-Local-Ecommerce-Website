<?php include "../headerr.php"; ?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Product</title>
    <link href="logoFavion.png" type="image/png" rel="shortcut icon">

<!--Boostrap CDN-->
<link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@4.5.3/dist/css/bootstrap.min.css" integrity="sha384-TX8t27EcRE3e/ihU7zmQxVncDAy5uIKz4rEkgIXeMed4M0jlfIDPvg6uqKI2xXr2" crossorigin="anonymous">
<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/css/bootstrap.min.css">

<!--Font Awesome CDN-->
<script src="https://kit.fontawesome.com/ba83dadc75.js" crossorigin="anonymous">
</script>

<!--Slick Slider-->
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/slick-carousel/1.9.0/slick.min.css" integrity="sha512-yHknP1/AwR+yx26cB1y0cjvQUMvEa2PFzt1c9LlS4pRQ5NOTZFWbhBig+X9G9eYW/8m0/4OXNx8pxJ6z57x0dw==" crossorigin="anonymous" />
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/slick-carousel/1.9.0/slick-theme.min.css" integrity="sha512-17EgCFERpgZKcm0j0fEq1YCJuyAWdz9KUtv1EjVuaOz8pDnh/0nZxmU6BBXwaaxqoi9PQXnRWqlcDB027hgv9A==" crossorigin="anonymous" />

<!--Custom Stylesheet-->
<link rel="stylesheet" href="stylephp.css">

</head>
<body>

<!-- reading products from database adminproducts -->
<?php

//trial ignore it
/*$idofproductSession = $_SESSION['id'];

echo  $idofproductSession; */

$ID=$_GET["id"];



$sql = "SELECT * FROM product WHERE id=$ID";
$result = $conn->query($sql);

if ($result->num_rows > 0) {
    while($row = $result->fetch_assoc()) {
      $idofproduct=$row["id"];
      $nameofproduct=$row["name"];
      $pictureofproduct=$row["image"];
      $priceofproduct=$row["price"];
      $descriptionofproduct=$row["description"];
      $categoryofproduct=$row["category"];

    }
}
else {
    echo "0 results";
  }



?>


<main>

<?php

$id=0;

$id=$_GET["id"];

$sql2 = "SELECT * FROM ratingproduct WHERE ratingProduct=$id";
$result2 = $conn->query($sql2);

$idofproduct2= array();
$customername= array();
$customerEmail=array();
$ratingNumStar=array(); //number of stars
$categoryofproductRate=array(); //category of product
$productID=array(); //id of product
$ratingText=array();
$m=0;
$index=0;

if ($result2->num_rows > 0) {
    while($row = $result2->fetch_assoc()) {
      $idofproduct2[$m]=$row["id"];
      $customername[$m]=$row["customerName"];
      $customerEmail[$m]=$row["Email"];
      $ratingText[$m]=$row["ratingText"];
      $ratingNumStar[$m]=$row["ratingNum"];  //number of stars
      $categoryofproductRate[$m]=$row["categoryProduct"];  //category of product
      $productID[$m]=$row["ratingProduct"]; //id of product
      $m++;
    }
}
else {
    //echo "0 results";
  }

 $index=$m;  //echo $index;
  $conn->close();

?>



<div class="container" id="product-section">
  <div class="row">
   <div class="col-md-6">
       <h2> <b> <?php echo $nameofproduct; ?> </b> </h2>

   <img src="data:image/jpeg;base64,<?php echo base64_encode($pictureofproduct); ?>" width="400px" height="400px" />
   </div>
   <div class="col-md-6">
    <br><h2 style="color:Red;"> <b> <?php echo $priceofproduct; echo "&nbsp;";echo "EGP"; ?> </b></h2>
    <h6>  All prices include VAT  </h6>
    <hr>
    <!-- if conditions to read id from database and display correspondant category name  -->
   <?php if($categoryofproduct==2){ $display="Fashion"; } ?>
   <?php if($categoryofproduct==1){ $display="Electronics"; } ?>
   <?php if($categoryofproduct==3){ $display="Supermarket"; } ?>
   <?php if($categoryofproduct==4){ $display="Toys"; } ?>
   <?php if($categoryofproduct==5){ $display="Mobiles"; } ?>

    <h5><b> Category: </b>&nbsp <?php echo $display; ?> </h5>  <br>
    <h5><b> Description: </b> &nbsp  <?php echo $descriptionofproduct; ?> </h5> <br>
    <a href="#" class="btn btn-info btn-lg"style="background-color:black; width: 250px;">
          <span class="glyphicon glyphicon-shopping-cart" style="color:white;" ></span> Go To Cart
        </a>
        <br> <br>
        <a href="ratingPage.php?category=<?php echo  $categoryofproduct;?>&id=<?php echo $id;?>" class="btn btn-info btn-lg"style="background-color:black; width: 250px;">
          <i class="fas fa-star"></i>&nbsp; Rate this product
        </a>
   </div>
  </div><!-- end row -->
 </div><!-- end container -->
<br>

 <div class="container" id="product-section">
  <div class="row">
   <div class="col-md-6" >
      <h2><b> Reviews and Rates </b></h2> <hr>
     <?php   for($p=0;$p<$index;$p++){  ?>
      <h3 style="color:#191970;"> <b> <?php echo $customername[$p]; ?> </b></h3>  <!-- customer name -->

      <h5 style="color:green;"> <i> <?php echo $customerEmail[$p]; ?> </i></h5>
      <h5 style="color:orange;">
      <!-- loop to display the checked stars -->
      <?php for($w=0;$w<5;$w++){
      if($w<=5){
        for($q=0;$q<$ratingNumStar[$p];$q++){ ?>
      <i class="fas fa-star"></i>
      <?php } break;}
        else{   ?><i class="fars fa-star"></i><?php } } ?>
       <i style="color:black;"> <?php echo$ratingNumStar[$p]; ?> out of 5</i></h5><!-- star rate -->

      <p style="color:black;">   <?php echo $ratingText[$p]; ?></p> <!-- full review --> <br>
      <?php } ?>
   </div>
   <div class="col-md-6">
    <!-- law 3ayza thoty haga fl gamb -->



   </div>
  </div><!-- end row -->
 </div><!-- end container -->

</main>


<br> <br>


  <script src="https://code.jquery.com/jquery-3.5.1.slim.min.js" integrity="sha384-DfXdz2htPH0lsSSs5nCTpuj/zy4C+OGpamoFVy38MVBnE+IbbVYUew+OrCXaRkfj" crossorigin="anonymous"></script>
  <script src="https://cdn.jsdelivr.net/npm/bootstrap@4.5.3/dist/js/bootstrap.bundle.min.js" integrity="sha384-ho+j7jyWK8fNQe+A12Hb8AhRq26LrZ/JpcUGGOn+Y7RsweNrtN/tE3MoK7ZeZDyx" crossorigin="anonymous">
  </script>
  <script src="https://cdnjs.cloudflare.com/ajax/libs/slick-carousel/1.9.0/slick.min.js" integrity="sha512-HGOnQO9+SP1V92SrtZfjqxxtLmVzqZpjFFekvzZVWoiASSQgSr4cw9Kqd2+l8Llp4Gm0G8GIFJ4ddwZilcdb8A==" crossorigin="anonymous"></script>
  <script src="D:college/Semester 5/Web Dev/project/farida's work/Be3ly/js/main.js"></script>
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>

  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/js/bootstrap.min.js"></script>
</body>
</html>
<?php include "../footer.php"; ?>
